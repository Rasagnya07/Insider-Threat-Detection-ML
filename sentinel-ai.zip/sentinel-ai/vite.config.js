import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Default Vite + React setup. No extra configuration needed.
export default defineConfig({
  plugins: [react()],
  server: { port: 5173 },
  build: {
    chunkSizeWarningLimit: 700,
    rollupOptions: {
      // Split the charting library into its own file to keep the main bundle small.
      output: { manualChunks: { recharts: ['recharts'] } },
    },
  },
});
