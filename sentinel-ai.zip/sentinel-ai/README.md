# SentinelAI - Insider Threat Detection Dashboard

A React + Vite frontend for an **Insider Threat Detection System using Elastic Net Regularized Logistic Regression** (SPEDIA Annotated Dataset).

> **Demo mode by default.** Out of the box the app runs on a *synthetic* dataset of 144 generated events and *simulated* predictions. It does not contain the SPEDIA dataset and no trained model is connected until you do it yourself (see below). Everything simulated is labelled as such in the UI.

**Stack:** React 18, Vite, JavaScript (JSX), plain CSS, React Router, Recharts, Lucide React, npm.

---

## 1. Run it in Visual Studio Code

1. Install [Node.js](https://nodejs.org/) 18 or newer (check with `node -v`).
2. In VS Code choose **File > Open Folder...** and select the `sentinel-ai` folder.
3. Open the integrated terminal (**Terminal > New Terminal**) and run:

```bash
npm install
npm run dev
```

4. Open the address Vite prints (normally <http://localhost:5173>).

Other scripts:

```bash
npm run build     # production build into dist/
npm run preview   # serve the production build locally
```

No other configuration is required.

## 2. Pages

| Route | Page | What it does |
|---|---|---|
| `/` | Overview | KPI cards, anomaly donut, risk distribution, activity timeline, activity breakdown, recent suspicious events |
| `/analytics` | Threat Analytics | Date / user / activity / action / threat-category filters driving every card, chart and table |
| `/logs` | Activity Logs | Search, filters, column sorting, pagination, row selection (+ CSV export), event detail drawer |
| `/prediction` | Prediction Lab | Validated form -> anomaly probability, risk band and gauge |
| `/performance` | Model Performance | Metrics, confusion matrix, classification report, configuration, regularization explainer |
| `/about` | About the Project | Project summary, workflow, risk interpretation |

The top-bar search filters the Overview, Threat Analytics and Activity Logs data. The bell lists the latest THREAT-band events and opens them in the Activity Logs drawer. The refresh button reloads the demo dataset, or re-checks the backend and re-fetches events when one is configured.

## 3. Risk categories

The classifier is binary (`Anomaly`: 0 or 1). The three display categories are **probability bands**, not trained classes. Logic lives in `src/utils/riskClassification.js`:

| Category | Anomaly probability |
|---|---|
| SAFE | below 0.34 |
| PARTIAL THREAT | 0.34 to below 0.67 |
| THREAT | 0.67 or higher |

The binary label used for "anomalous" counts is `probability >= 0.5` (`LABEL_CUTOFF`). Change it in one place if your model uses a different cut-off.

## 4. Project structure

```text
sentinel-ai/
├── public/favicon.svg
├── src/
│   ├── components/      Sidebar, Topbar, StatCard, ChartCard, ThreatBadge, EventTable,
│   │                    EventDetails (drawer), ProbabilityGauge, DonutChart, HBarChart, ...
│   ├── pages/           Overview, ThreatAnalytics, ActivityLogs, PredictionLab,
│   │                    ModelPerformance, AboutProject
│   ├── context/         DataContext.jsx  (events, search, refresh, data-source status)
│   ├── data/            demoData.js (seeded synthetic events), constants.js, modelMetrics.json
│   ├── services/        api.js (ALL backend calls; demo fallback)
│   ├── utils/           riskClassification.js, analytics.js, validation.js, formatters.js,
│   │                    demoModel.js (simulated scoring, demo mode only), theme.js
│   ├── navConfig.js     routes shared by sidebar and top bar
│   ├── App.jsx, main.jsx, index.css
├── .env.example
└── package.json
```

Every page reads the **same** `events` array from `DataContext`, and every count and percentage is computed from it in `src/utils/analytics.js`, so KPI cards, charts, tables and filters always agree.

## 5. Connecting a real backend

Copy `.env.example` to `.env` and set the URL of your ML service, then restart `npm run dev`:

```env
VITE_API_BASE_URL=http://localhost:5000
```

If the variable is missing or empty the app stays in demo mode and makes **no** network requests. If it is set but the server cannot be reached, the dashboard falls back to demo data and labels it as such. It never presents simulated numbers as model output.

Your backend must allow CORS for the Vite origin (for Flask: `flask-cors`).

### API contract

All bodies are JSON. Only `/api/predict` is required for the Prediction Lab; the others are optional.

#### `GET /api/health`
Used to detect the backend. Any `200` response means "connected".
```json
{ "status": "ok" }
```

#### `POST /api/predict`  (Prediction Lab)

Request body:
```json
{
  "user": "s.novak",
  "agent": "WKS-PRG-003",
  "decoder": "proxy_gateway",
  "activity": "Web Upload",
  "action": "upload",
  "logLevel": "warning",
  "eventSize": 48000000,
  "attachments": 3,
  "sizeBefore": 48000000,
  "sizeAfter": 48000000,
  "timestamp": "2026-10-14T02:15:00.000Z"
}
```

Response body:
```json
{
  "probability": 0.82,
  "label": 1,
  "riskCategory": "THREAT"
}
```

* `probability`: float in `[0, 1]`, the predicted anomaly probability (`predict_proba(...)[:, 1]`). **Required.**
* `label`: `0` or `1`. Optional; derived from the probability if missing.
* `riskCategory`: `"SAFE"`, `"PARTIAL THREAT"` or `"THREAT"`. Optional; derived from the probability with the thresholds above if missing.
* `snake_case` aliases are also accepted: `anomaly_probability`, `predicted_label`, `risk_category`.

#### `GET /api/events`  (optional, replaces the demo dataset)
```json
{
  "events": [
    {
      "id": "EVT-00001",
      "timestamp": "2026-10-01T05:00:26.000Z",
      "user": "k.haddad",
      "agent": "WKS-DXB-016",
      "decoder": "sysmon",
      "activity": "File Access",
      "action": "delete",
      "logLevel": "info",
      "eventSize": 2242,
      "attachments": 0,
      "sizeBefore": 2242,
      "sizeAfter": 0,
      "probability": 0.492
    }
  ]
}
```
`label` and `riskCategory` are optional and computed from `probability` when absent. Field names are matched in camelCase or snake_case (`event_size`, `activity_type`, `action_type`, ...). Records without a numeric probability are skipped.

#### `GET /api/metrics`  (optional)
Same shape as `src/data/modelMetrics.json` (see section 7). If the call fails the app uses the local file.

### Minimal Flask example

```python
# app.py  -  pip install flask flask-cors scikit-learn joblib pandas
import joblib, pandas as pd
from flask import Flask, jsonify, request
from flask_cors import CORS

app = Flask(__name__)
CORS(app)
# A fitted sklearn Pipeline: preprocessing (encoding + scaling) + LogisticRegression(penalty="elasticnet", ...)
model = joblib.load("elastic_net_pipeline.joblib")

def band(p):
    return "THREAT" if p >= 0.67 else "PARTIAL THREAT" if p >= 0.34 else "SAFE"

@app.get("/api/health")
def health():
    return jsonify(status="ok")

@app.post("/api/predict")
def predict():
    row = pd.DataFrame([request.get_json()])      # rename columns here to match your training data
    p = float(model.predict_proba(row)[0, 1])
    return jsonify(probability=p, label=int(p >= 0.5), riskCategory=band(p))

if __name__ == "__main__":
    app.run(port=5000)
```

The column names and preprocessing must match what the model was trained on. Adapt the `pd.DataFrame` line accordingly.

## 6. Replacing the demo data with real SPEDIA records

1. Run your trained model over the SPEDIA test records and store the anomaly probability for each.
2. Either:
   * **Serve them** from `GET /api/events` (recommended for large data), or
   * **Replace the demo records**: export an array of event objects (fields as in the `/api/events` example above) into `src/data/demoData.js` and export it as `DEMO_EVENTS`. Remove or ignore the generator.
3. If you load real records, set `simulated: false` on each one (the backend path does this automatically). The UI then drops the "simulated" labels for those events.
4. Update the vocabulary in `src/data/constants.js` (users, agents, decoders, activities, actions) so the Prediction Lab dropdowns match your data. Filter options on other pages are derived from the loaded events automatically.
5. Update `DEMO_META` wording or remove the banner once real data is in use.

## 7. Model metrics

The Model Performance page shows **"Awaiting model results"** until you provide numbers. Fill in `src/data/modelMetrics.json` (or serve the same JSON from `/api/metrics`). Rates are fractions between 0 and 1. The numbers below are only an example of the format, not results:

```json
{
  "accuracy": 0.0,
  "precision": 0.0,
  "recall": 0.0,
  "f1": 0.0,
  "rocAuc": 0.0,
  "trainAccuracy": 0.0,
  "testAccuracy": 0.0,
  "confusionMatrix": { "tn": 0, "fp": 0, "fn": 0, "tp": 0 },
  "classificationReport": [
    { "label": "0 (Non-anomalous)", "precision": 0.0, "recall": 0.0, "f1": 0.0, "support": 0 },
    { "label": "1 (Anomalous)",     "precision": 0.0, "recall": 0.0, "f1": 0.0, "support": 0 },
    { "label": "Macro average",     "precision": 0.0, "recall": 0.0, "f1": 0.0, "support": 0 },
    { "label": "Weighted average",  "precision": 0.0, "recall": 0.0, "f1": 0.0, "support": 0 }
  ],
  "classDistribution": {
    "actual":    { "0": 0, "1": 0 },
    "predicted": { "0": 0, "1": 0 }
  }
}
```

Each card, chart and table switches from the placeholder to real values independently as soon as its field is non-null. With scikit-learn, `confusion_matrix(y_test, pred).ravel()` returns `tn, fp, fn, tp` in that order, and `classification_report(..., output_dict=True)` has the per-class numbers.

## 8. Troubleshooting

* **`npm install` fails** - check `node -v` (needs 18+) and your network/proxy.
* **Port already in use** - Vite picks the next free port; use the URL it prints.
* **Backend not detected** - confirm `.env` is in the project root (next to `package.json`), restart `npm run dev`, and check CORS and that `/api/health` returns `200`.
* **Environment variable changes not applied** - Vite reads `.env` only at start-up.
