import { useCallback, useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Download, FilterX, Search, X } from 'lucide-react';
import { useData } from '../context/DataContext';
import { downloadCsv, eventsToCsv, sortEvents, uniqueValues } from '../utils/analytics';
import { RISK_ORDER } from '../utils/riskClassification';
import EventTable from '../components/EventTable';
import EventDetails from '../components/EventDetails';
import Pagination from '../components/Pagination';
import FilterSelect from '../components/FilterSelect';
import DataBanner from '../components/DataBanner';
import EmptyState from '../components/EmptyState';

export default function ActivityLogs() {
  const { events: allEvents, searchedEvents, search, setSearch, status } = useData();
  const [searchParams, setSearchParams] = useSearchParams();
  const [risk, setRisk] = useState('');
  const [activity, setActivity] = useState('');
  const [sort, setSort] = useState({ key: 'timestamp', direction: 'desc' });
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [selectedIds, setSelectedIds] = useState(() => new Set());

  // The drawer is driven by ?event=<id> so notifications can deep-link to an event.
  const openId = searchParams.get('event');
  const openEvent = useMemo(() => allEvents.find((e) => e.id === openId) || null, [allEvents, openId]);
  const openDetails = useCallback((event) => setSearchParams({ event: event.id }), [setSearchParams]);
  const closeDetails = useCallback(() => setSearchParams({}), [setSearchParams]);

  const activities = useMemo(() => uniqueValues(allEvents, 'activity'), [allEvents]);

  const filtered = useMemo(
    () => searchedEvents.filter((e) => (!risk || e.risk === risk) && (!activity || e.activity === activity)),
    [searchedEvents, risk, activity],
  );
  const sorted = useMemo(() => sortEvents(filtered, sort.key, sort.direction), [filtered, sort]);
  const pageRows = useMemo(() => sorted.slice((page - 1) * pageSize, page * pageSize), [sorted, page, pageSize]);

  // Back to page 1 whenever the result set changes shape.
  useEffect(() => {
    setPage(1);
  }, [search, risk, activity, sort, pageSize]);

  const onSort = (key) =>
    setSort((current) =>
      current.key === key ? { key, direction: current.direction === 'asc' ? 'desc' : 'asc' } : { key, direction: 'asc' },
    );

  const toggleOne = (id) =>
    setSelectedIds((current) => {
      const next = new Set(current);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });

  const toggleMany = (ids, checked) =>
    setSelectedIds((current) => {
      const next = new Set(current);
      ids.forEach((id) => (checked ? next.add(id) : next.delete(id)));
      return next;
    });

  const clearFilters = () => {
    setRisk('');
    setActivity('');
    setSearch('');
  };

  const exportSelected = () => {
    const rows = allEvents.filter((e) => selectedIds.has(e.id));
    downloadCsv('sentinelai-selected-events.csv', eventsToCsv(rows));
  };

  const filtersActive = Boolean(risk || activity || search);

  return (
    <div className="page">
      <p className="page-desc">
        Search, filter and sort every analysed event. Click a row to see its full details and risk estimate.
      </p>
      <DataBanner shown={searchedEvents.length} total={allEvents.length} />

      <section className="card">
        <div className="filters filters--logs">
          <label className="search search--page">
            <Search size={16} />
            <input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by user, event ID, activity or action"
              aria-label="Search events"
            />
          </label>
          <FilterSelect label="Risk category" value={risk} onChange={setRisk} options={RISK_ORDER} />
          <FilterSelect label="Activity type" value={activity} onChange={setActivity} options={activities} />
          <button type="button" className="btn btn--ghost" onClick={clearFilters} disabled={!filtersActive}>
            <FilterX size={15} /> Clear filters
          </button>
        </div>

        {selectedIds.size > 0 && (
          <div className="selection-bar" role="status">
            <span>{selectedIds.size} selected</span>
            <button type="button" className="btn btn--ghost btn--small" onClick={exportSelected}>
              <Download size={13} /> Export CSV
            </button>
            <button type="button" className="btn btn--ghost btn--small" onClick={() => setSelectedIds(new Set())}>
              <X size={13} /> Clear selection
            </button>
          </div>
        )}

        {status === 'loading' && allEvents.length === 0 ? (
          <div className="loading-row">
            <span className="spinner" /> Loading events...
          </div>
        ) : sorted.length === 0 ? (
          <EmptyState
            title="No events match your search"
            message="Try a different search term or clear the filters."
            actionLabel="Clear filters"
            onAction={clearFilters}
          />
        ) : (
          <>
            <EventTable
              events={pageRows}
              sort={sort}
              onSort={onSort}
              selectedIds={selectedIds}
              onToggle={toggleOne}
              onToggleAll={toggleMany}
              onRowClick={openDetails}
              activeId={openId}
            />
            <Pagination page={page} pageSize={pageSize} total={sorted.length} onPage={setPage} onPageSize={setPageSize} />
          </>
        )}
      </section>

      <EventDetails event={openEvent} onClose={closeDetails} />
    </div>
  );
}
