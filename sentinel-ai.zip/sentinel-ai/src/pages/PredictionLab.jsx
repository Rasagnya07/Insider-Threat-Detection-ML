import { useState } from 'react';
import { AlertCircle, FlaskConical, Info, RotateCcw, Zap } from 'lucide-react';
import { ACTIONS, ACTIVITIES, AGENTS, DECODERS, LOG_LEVELS, USERS } from '../data/constants';
import { API_BASE_URL, isBackendConfigured, predictEvent } from '../services/api';
import { validateEventForm } from '../utils/validation';
import { explainResult, RISK_META } from '../utils/riskClassification';
import { formatPercent } from '../utils/formatters';
import ProbabilityGauge from '../components/ProbabilityGauge';
import ThreatBadge from '../components/ThreatBadge';

const nowForInput = () => new Date().toISOString().slice(0, 16);

const blankForm = () => ({
  user: '',
  agent: '',
  decoder: '',
  activity: '',
  action: '',
  logLevel: 'info',
  eventSize: '',
  attachments: '0',
  sizeBefore: '',
  sizeAfter: '',
  timestamp: nowForInput(),
});

// One-click examples so the form is quick to demonstrate.
const SAMPLES = [
  {
    label: 'Routine login',
    values: {
      user: 'a.sharma', agent: 'WKS-HYD-014', decoder: 'windows_eventlog', activity: 'Login', action: 'login',
      logLevel: 'info', eventSize: '640', attachments: '0', sizeBefore: '640', sizeAfter: '640', timestamp: '2026-10-14T09:30',
    },
  },
  {
    label: 'Large off-hours upload',
    values: {
      user: 's.novak', agent: 'WKS-PRG-003', decoder: 'proxy_gateway', activity: 'Web Upload', action: 'upload',
      logLevel: 'warning', eventSize: '48000000', attachments: '3', sizeBefore: '48000000', sizeAfter: '48000000', timestamp: '2026-10-14T02:15',
    },
  },
];

function Field({ label, error, children, hint }) {
  return (
    <label className="field">
      <span className="field__label">{label}</span>
      {children}
      {hint && !error && <span className="field__hint">{hint}</span>}
      {error && <span className="field__error">{error}</span>}
    </label>
  );
}

export default function PredictionLab() {
  const [form, setForm] = useState(blankForm);
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [requestError, setRequestError] = useState('');

  const update = (key) => (event) => {
    setForm((current) => ({ ...current, [key]: event.target.value }));
    if (errors[key]) setErrors((current) => ({ ...current, [key]: undefined }));
  };

  const props = (key) => ({
    value: form[key],
    onChange: update(key),
    'aria-invalid': errors[key] ? 'true' : undefined,
  });

  const reset = () => {
    setForm(blankForm());
    setErrors({});
    setResult(null);
    setRequestError('');
  };

  const submit = async (event) => {
    event.preventDefault();
    const { errors: found, values } = validateEventForm(form);
    setErrors(found);
    setRequestError('');
    if (Object.keys(found).length > 0) return;

    setLoading(true);
    setResult(null);
    try {
      setResult(await predictEvent(values));
    } catch (error) {
      setRequestError(error.message || 'Prediction failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page">
      <p className="page-desc">
        Enter the details of a new activity event to get a model-based anomaly risk estimate.
      </p>

      <div className={`notice ${isBackendConfigured ? 'notice--info' : 'notice--demo'}`}>
        <Info size={16} />
        <span>
          {isBackendConfigured ? (
            <>
              Predictions are requested from <strong>{API_BASE_URL}/api/predict</strong>. If it cannot be reached, a clearly
              labelled simulated result is shown instead.
            </>
          ) : (
            <>
              <strong>Demo mode.</strong> No backend is configured, so results are simulated demo predictions from a
              simple heuristic, not output from the trained model.
            </>
          )}
        </span>
      </div>

      <div className="lab">
        <form className="card" onSubmit={submit} noValidate>
          <header className="card__header card__header--row">
            <div>
              <h2 className="card__title">Event details</h2>
              <p className="card__subtitle">All fields are required. Sizes are in bytes; time is UTC.</p>
            </div>
          </header>

          <div className="chips" aria-label="Sample events">
            <span className="muted small">Try a sample:</span>
            {SAMPLES.map((sample) => (
              <button
                type="button"
                key={sample.label}
                className="chip"
                onClick={() => {
                  setForm(sample.values);
                  setErrors({});
                }}
              >
                {sample.label}
              </button>
            ))}
          </div>

          <div className="form-grid">
            <Field label="User" error={errors.user}>
              <input className="input" list="user-options" placeholder="e.g. a.sharma" {...props('user')} />
            </Field>
            <Field label="Agent name" error={errors.agent}>
              <input className="input" list="agent-options" placeholder="e.g. WKS-HYD-014" {...props('agent')} />
            </Field>
            <Field label="Decoder name" error={errors.decoder}>
              <input className="input" list="decoder-options" placeholder="e.g. fileserver_audit" {...props('decoder')} />
            </Field>
            <Field label="Activity type" error={errors.activity}>
              <select className="select" {...props('activity')}>
                <option value="">Select activity</option>
                {ACTIVITIES.map((a) => (
                  <option key={a}>{a}</option>
                ))}
              </select>
            </Field>
            <Field label="Action type" error={errors.action}>
              <select className="select" {...props('action')}>
                <option value="">Select action</option>
                {ACTIONS.map((a) => (
                  <option key={a}>{a}</option>
                ))}
              </select>
            </Field>
            <Field label="Log level" error={errors.logLevel}>
              <select className="select" {...props('logLevel')}>
                {LOG_LEVELS.map((l) => (
                  <option key={l}>{l}</option>
                ))}
              </select>
            </Field>
            <Field label="Event size (bytes)" error={errors.eventSize}>
              <input className="input" type="number" min="0" step="1" inputMode="numeric" placeholder="0" {...props('eventSize')} />
            </Field>
            <Field label="Attachment count" error={errors.attachments}>
              <input className="input" type="number" min="0" max="100" step="1" inputMode="numeric" {...props('attachments')} />
            </Field>
            <Field label="Size before operation (bytes)" error={errors.sizeBefore}>
              <input className="input" type="number" min="0" step="1" inputMode="numeric" placeholder="0" {...props('sizeBefore')} />
            </Field>
            <Field label="Size after operation (bytes)" error={errors.sizeAfter}>
              <input className="input" type="number" min="0" step="1" inputMode="numeric" placeholder="0" {...props('sizeAfter')} />
            </Field>
            <Field label="Timestamp (UTC)" error={errors.timestamp}>
              <input className="input" type="datetime-local" {...props('timestamp')} />
            </Field>
          </div>

          <datalist id="user-options">
            {USERS.map((u) => (
              <option key={u} value={u} />
            ))}
          </datalist>
          <datalist id="agent-options">
            {AGENTS.map((a) => (
              <option key={a} value={a} />
            ))}
          </datalist>
          <datalist id="decoder-options">
            {DECODERS.map((d) => (
              <option key={d} value={d} />
            ))}
          </datalist>

          {Object.keys(errors).some((k) => errors[k]) && (
            <div className="notice notice--error" role="alert">
              <AlertCircle size={16} />
              <span>Please fix the highlighted fields and try again.</span>
            </div>
          )}

          <div className="form-actions">
            <button type="submit" className="btn btn--primary" disabled={loading}>
              {loading ? <span className="spinner spinner--small" /> : <Zap size={16} />}
              {loading ? 'Analyzing...' : 'Analyze Event'}
            </button>
            <button type="button" className="btn btn--ghost" onClick={reset} disabled={loading}>
              <RotateCcw size={15} /> Reset form
            </button>
          </div>
        </form>

        <section className="card result" aria-live="polite">
          <header className="card__header">
            <h2 className="card__title">Risk estimate</h2>
          </header>

          {loading && (
            <div className="result__state">
              <span className="spinner" />
              <p>Analyzing event...</p>
            </div>
          )}

          {!loading && requestError && (
            <div className="notice notice--error" role="alert">
              <AlertCircle size={16} />
              <span>{requestError}</span>
            </div>
          )}

          {!loading && !result && !requestError && (
            <div className="result__state result__state--idle">
              <FlaskConical size={30} />
              <p>Fill in the form and choose <strong>Analyze Event</strong> to see the predicted anomaly probability and risk category.</p>
            </div>
          )}

          {!loading && result && (
            <div className="result__body">
              <ProbabilityGauge probability={result.probability} size={260} />
              <div className="result__badges">
                <ThreatBadge risk={result.riskCategory} />
                {result.simulated ? (
                  <span className="pill pill--demo">
                    <FlaskConical size={13} /> Simulated demo prediction
                  </span>
                ) : (
                  <span className="pill pill--ok">Output from backend model</span>
                )}
              </div>

              <dl className="detail-grid detail-grid--compact">
                <div>
                  <dt>Anomaly probability</dt>
                  <dd>{formatPercent(result.probability)}</dd>
                </div>
                <div>
                  <dt>Predicted label</dt>
                  <dd>{result.label === 1 ? '1 - Anomalous' : '0 - Non-anomalous'}</dd>
                </div>
                <div>
                  <dt>Risk band</dt>
                  <dd>{RISK_META[result.riskCategory].range}</dd>
                </div>
              </dl>

              <p className="result__explain">{explainResult(result.probability, result.riskCategory, result.simulated)}</p>
              {result.fallbackReason && <p className="muted small">{result.fallbackReason}</p>}

              <button type="button" className="btn btn--ghost" onClick={reset}>
                <RotateCcw size={15} /> Analyze another event
              </button>
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
