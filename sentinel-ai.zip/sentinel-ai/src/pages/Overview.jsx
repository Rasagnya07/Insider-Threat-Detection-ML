import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Activity, AlertTriangle, ArrowRight, ShieldAlert, ShieldCheck, TrendingUp } from 'lucide-react';
import {
  Bar, BarChart, CartesianGrid, Cell, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from 'recharts';
import { useData } from '../context/DataContext';
import { countBy, riskDistribution, summarize, timelineByDay } from '../utils/analytics';
import { formatNumber, formatPercent } from '../utils/formatters';
import { RISK, RISK_META } from '../utils/riskClassification';
import { AXIS_TICK, CHART } from '../utils/theme';
import StatCard from '../components/StatCard';
import ChartCard from '../components/ChartCard';
import ChartTooltip from '../components/ChartTooltip';
import DonutChart from '../components/DonutChart';
import HBarChart from '../components/HBarChart';
import EventTable from '../components/EventTable';
import EventDetails from '../components/EventDetails';
import DataBanner from '../components/DataBanner';
import EmptyState from '../components/EmptyState';

const SUSPICIOUS_COLUMNS = ['timestamp', 'user', 'activity', 'action', 'probability', 'risk'];

export default function Overview() {
  const { searchedEvents: events, events: allEvents } = useData();
  const [openEvent, setOpenEvent] = useState(null);

  const summary = useMemo(() => summarize(events), [events]);
  const anomalyData = [
    { name: 'Normal', value: summary.normal, color: CHART.normal },
    { name: 'Anomalous', value: summary.anomalous, color: CHART.anomalous },
  ];
  const riskData = useMemo(
    () => riskDistribution(events).map((d) => ({ ...d, color: RISK_META[d.name].color })),
    [events],
  );
  const timeline = useMemo(() => timelineByDay(events), [events]);
  const activityData = useMemo(() => countBy(events, (e) => e.activity, { limit: 8 }), [events]);
  const suspicious = useMemo(
    () =>
      events
        .filter((e) => e.risk !== RISK.SAFE)
        .sort((a, b) => b.timestamp.localeCompare(a.timestamp))
        .slice(0, 8),
    [events],
  );

  const noEvents = events.length === 0;

  return (
    <div className="page">
      <p className="page-desc">
        Model-flagged activity across all analysed events. Risk categories are probability bands from a binary classifier.
      </p>
      <DataBanner shown={events.length} total={allEvents.length} />

      {noEvents ? (
        <EmptyState
          title="No events to display"
          message="No events match the current search, or the data source returned no records."
        />
      ) : (
        <>
          <div className="kpi-grid">
            <StatCard icon={Activity} label="Total Events Analysed" value={formatNumber(summary.total)} hint="Events in current view" tone="blue" />
            <StatCard
              icon={AlertTriangle}
              label="Anomalous Events"
              value={formatNumber(summary.anomalous)}
              hint={`${formatPercent(summary.anomalyRate)} of events (label = 1)`}
              tone="violet"
            />
            <StatCard icon={ShieldCheck} label="Safe Events" value={formatNumber(summary.safe)} hint="Probability below 0.34" tone="green" />
            <StatCard icon={TrendingUp} label="Threat Rate" value={formatPercent(summary.threatRate)} hint={`${formatNumber(summary.threat)} THREAT events`} tone="red" />
            <StatCard icon={ShieldAlert} label="Partial Threats" value={formatNumber(summary.partial)} hint="Probability 0.34 to below 0.67" tone="amber" />
          </div>

          <div className="grid-2">
            <ChartCard title="Anomaly Distribution" subtitle="Normal vs model-flagged anomalous events" height={240}>
              <DonutChart data={anomalyData} centerValue={formatPercent(summary.anomalyRate, 0)} centerLabel="anomalous" />
            </ChartCard>

            <ChartCard title="Threat Risk Distribution" subtitle="SAFE, PARTIAL THREAT and THREAT bands" height={240}>
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={riskData} margin={{ top: 8, right: 8, bottom: 0, left: -12 }}>
                  <CartesianGrid stroke={CHART.grid} vertical={false} />
                  <XAxis dataKey="name" tick={AXIS_TICK} axisLine={false} tickLine={false} />
                  <YAxis allowDecimals={false} tick={AXIS_TICK} axisLine={false} tickLine={false} />
                  <Tooltip content={<ChartTooltip />} cursor={{ fill: 'rgba(139,124,246,0.08)' }} />
                  <Bar dataKey="value" name="Events" radius={[4, 4, 0, 0]} maxBarSize={72} isAnimationActive={false}>
                    {riskData.map((d) => (
                      <Cell key={d.name} fill={d.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </ChartCard>
          </div>

          <ChartCard title="Activity Timeline" subtitle="Events per day (UTC) and how many were flagged anomalous" height={280}>
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={timeline} margin={{ top: 8, right: 16, bottom: 0, left: -12 }}>
                <CartesianGrid stroke={CHART.grid} vertical={false} />
                <XAxis dataKey="label" tick={AXIS_TICK} axisLine={false} tickLine={false} minTickGap={16} />
                <YAxis allowDecimals={false} tick={AXIS_TICK} axisLine={false} tickLine={false} />
                <Tooltip content={<ChartTooltip />} />
                <Legend wrapperStyle={{ color: CHART.tick, fontSize: 12 }} />
                <Line type="monotone" dataKey="events" name="All events" stroke={CHART.cyan} strokeWidth={2} dot={false} isAnimationActive={false} />
                <Line type="monotone" dataKey="anomalies" name="Anomalous" stroke={CHART.anomalous} strokeWidth={2} dot={false} isAnimationActive={false} />
              </LineChart>
            </ResponsiveContainer>
          </ChartCard>

          <div className="grid-2 grid-2--wide-right">
            <ChartCard title="Activity Type Breakdown" subtitle="Most frequent activity types" height={300}>
              <HBarChart data={activityData} color={CHART.blue} />
            </ChartCard>

            <section className="card">
              <header className="card__header card__header--row">
                <div>
                  <h2 className="card__title">Recent Suspicious Events</h2>
                  <p className="card__subtitle">Latest PARTIAL THREAT and THREAT events (potentially suspicious, needs review)</p>
                </div>
                <Link to="/logs" className="link-btn">
                  All logs <ArrowRight size={14} />
                </Link>
              </header>
              {suspicious.length === 0 ? (
                <EmptyState title="No suspicious events" message="Nothing in the current view fell outside the SAFE band." />
              ) : (
                <EventTable events={suspicious} columns={SUSPICIOUS_COLUMNS} onRowClick={setOpenEvent} activeId={openEvent?.id} />
              )}
            </section>
          </div>
        </>
      )}

      <EventDetails event={openEvent} onClose={() => setOpenEvent(null)} />
    </div>
  );
}
