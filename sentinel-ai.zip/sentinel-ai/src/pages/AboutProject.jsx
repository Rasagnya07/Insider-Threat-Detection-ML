import { ArrowRight, Cpu, Database, Eraser, LayoutDashboard, Percent, ShieldAlert, SlidersHorizontal } from 'lucide-react';
import { RISK_META, RISK_ORDER } from '../utils/riskClassification';
import ThreatBadge from '../components/ThreatBadge';

const FACTS = [
  ['Project title', 'Insider Threat Detection Using Elastic Net Regularized Logistic Regression'],
  ['Dataset', 'SPEDIA Annotated Dataset'],
  ['Objective', 'Analyze activity logs to identify potentially anomalous user and system behaviour.'],
  ['Algorithm', 'Elastic Net Regularized Logistic Regression'],
  ['Target variable', 'Anomaly: 0 = non-anomalous events, 1 = anomalous events'],
];

const WORKFLOW = [
  { label: 'Dataset', icon: Database },
  { label: 'Data Preprocessing', icon: Eraser },
  { label: 'Feature Encoding and Scaling', icon: SlidersHorizontal },
  { label: 'Elastic Net Logistic Regression', icon: Cpu },
  { label: 'Anomaly Probability', icon: Percent },
  { label: 'Risk Classification', icon: ShieldAlert },
  { label: 'Dashboard', icon: LayoutDashboard },
];

export default function AboutProject() {
  return (
    <div className="page">
      <p className="page-desc">A university project demonstrating probability-based insider threat detection on activity logs.</p>

      <section className="card">
        <header className="card__header">
          <h2 className="card__title">Project summary</h2>
        </header>
        <dl className="facts">
          {FACTS.map(([key, value]) => (
            <div key={key}>
              <dt>{key}</dt>
              <dd>{value}</dd>
            </div>
          ))}
        </dl>
      </section>

      <section className="card">
        <header className="card__header">
          <h2 className="card__title">Workflow</h2>
          <p className="card__subtitle">From raw logs to the dashboard you are looking at</p>
        </header>
        <ol className="workflow">
          {WORKFLOW.map(({ label, icon: Icon }, index) => (
            <li key={label} className="workflow__step">
              <span className="workflow__node">
                <span className="workflow__icon">
                  <Icon size={18} />
                </span>
                <span className="workflow__label">{label}</span>
              </span>
              {index < WORKFLOW.length - 1 && <ArrowRight size={16} className="workflow__arrow" aria-hidden="true" />}
            </li>
          ))}
        </ol>
      </section>

      <div className="grid-2">
        <section className="card">
          <header className="card__header">
            <h2 className="card__title">Risk interpretation</h2>
          </header>
          <p className="muted">
            The classifier is trained on two labels only (0 and 1). The three risk categories below are derived from the
            predicted anomaly probability; they are not three independently trained classes.
          </p>
          <ul className="risk-list">
            {RISK_ORDER.map((risk) => (
              <li key={risk}>
                <ThreatBadge risk={risk} />
                <span>
                  Anomaly probability {RISK_META[risk].range}
                </span>
              </li>
            ))}
          </ul>
        </section>

        <section className="card">
          <header className="card__header">
            <h2 className="card__title">Responsible interpretation</h2>
          </header>
          <ul className="bullets">
            <li>A model-flagged anomaly is potentially suspicious behaviour, not proof of malicious intent.</li>
            <li>Results should be reviewed by a human analyst before any action is taken.</li>
            <li>
              The data shown in this app is <strong>synthetic demo data</strong> with simulated predictions unless a real
              dataset and model have been connected.
            </li>
          </ul>
        </section>
      </div>
    </div>
  );
}
