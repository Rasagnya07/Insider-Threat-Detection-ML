import { useMemo, useState } from 'react';
import { Activity, AlertTriangle, FilterX, Percent, ShieldAlert } from 'lucide-react';
import { Bar, BarChart, CartesianGrid, Cell, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { useData } from '../context/DataContext';
import {
  EMPTY_FILTERS, applyFilters, countBy, eventsByHour, hasActiveFilters, riskDistribution, sizeDistribution,
  summarize, uniqueValues,
} from '../utils/analytics';
import { formatNumber, formatPercent } from '../utils/formatters';
import { RISK_META, RISK_ORDER } from '../utils/riskClassification';
import { AXIS_TICK, CHART } from '../utils/theme';
import StatCard from '../components/StatCard';
import ChartCard from '../components/ChartCard';
import ChartTooltip from '../components/ChartTooltip';
import HBarChart from '../components/HBarChart';
import FilterSelect from '../components/FilterSelect';
import EventTable from '../components/EventTable';
import EventDetails from '../components/EventDetails';
import DataBanner from '../components/DataBanner';
import EmptyState from '../components/EmptyState';

const TOP_COLUMNS = ['id', 'timestamp', 'user', 'activity', 'action', 'probability', 'risk'];

const STACK_COLORS = { normal: CHART.normal, anomalous: CHART.anomalous };

// Stacked normal/anomalous columns, used for event size and hour-of-day charts.
function StackedColumns({ data, xKey, minTickGap = 0 }) {
  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart data={data} margin={{ top: 8, right: 8, bottom: 0, left: -12 }}>
        <CartesianGrid stroke={CHART.grid} vertical={false} />
        <XAxis dataKey={xKey} tick={AXIS_TICK} axisLine={false} tickLine={false} minTickGap={minTickGap} />
        <YAxis allowDecimals={false} tick={AXIS_TICK} axisLine={false} tickLine={false} />
        <Tooltip content={<ChartTooltip />} cursor={{ fill: 'rgba(139,124,246,0.08)' }} />
        <Legend wrapperStyle={{ color: CHART.tick, fontSize: 12 }} />
        <Bar dataKey="normal" name="Normal" stackId="a" fill={STACK_COLORS.normal} isAnimationActive={false} />
        <Bar dataKey="anomalous" name="Model-flagged anomaly" stackId="a" fill={STACK_COLORS.anomalous} radius={[3, 3, 0, 0]} isAnimationActive={false} />
      </BarChart>
    </ResponsiveContainer>
  );
}

export default function ThreatAnalytics() {
  const { searchedEvents, events: allEvents } = useData();
  const [filters, setFilters] = useState(EMPTY_FILTERS);
  const [openEvent, setOpenEvent] = useState(null);

  const setFilter = (key) => (value) => setFilters((current) => ({ ...current, [key]: value }));

  // Filter options come from the (search-narrowed) data, so they always match real values.
  const options = useMemo(
    () => ({
      user: uniqueValues(searchedEvents, 'user'),
      activity: uniqueValues(searchedEvents, 'activity'),
      action: uniqueValues(searchedEvents, 'action'),
    }),
    [searchedEvents],
  );

  const events = useMemo(() => applyFilters(searchedEvents, filters), [searchedEvents, filters]);
  const summary = useMemo(() => summarize(events), [events]);

  const riskData = useMemo(() => riskDistribution(events).map((d) => ({ ...d, color: RISK_META[d.name].color })), [events]);
  const byActivity = useMemo(() => countBy(events, (e) => e.activity, { onlyAnomalous: true }), [events]);
  const byUser = useMemo(() => countBy(events, (e) => e.user, { onlyAnomalous: true, limit: 8 }), [events]);
  const byDecoder = useMemo(() => countBy(events, (e) => e.decoder, { onlyAnomalous: true }), [events]);
  const sizes = useMemo(() => sizeDistribution(events), [events]);
  const hours = useMemo(() => eventsByHour(events), [events]);
  const topEvents = useMemo(() => [...events].sort((a, b) => b.probability - a.probability).slice(0, 10), [events]);

  const filtered = hasActiveFilters(filters);

  return (
    <div className="page">
      <p className="page-desc">
        Investigate model-flagged anomalies. Flags are potentially suspicious and need analyst review; an anomaly alone
        does not establish malicious intent.
      </p>
      <DataBanner shown={searchedEvents.length} total={allEvents.length} />

      <section className="card filters-card" aria-label="Filters">
        <div className="filters">
          <label className="field field--inline">
            <span className="field__label">From</span>
            <input type="date" className="input" value={filters.from} max={filters.to || undefined} onChange={(e) => setFilter('from')(e.target.value)} />
          </label>
          <label className="field field--inline">
            <span className="field__label">To</span>
            <input type="date" className="input" value={filters.to} min={filters.from || undefined} onChange={(e) => setFilter('to')(e.target.value)} />
          </label>
          <FilterSelect label="User" value={filters.user} onChange={setFilter('user')} options={options.user} />
          <FilterSelect label="Activity type" value={filters.activity} onChange={setFilter('activity')} options={options.activity} />
          <FilterSelect label="Action type" value={filters.action} onChange={setFilter('action')} options={options.action} />
          <FilterSelect label="Threat category" value={filters.risk} onChange={setFilter('risk')} options={RISK_ORDER} />
          <button type="button" className="btn btn--ghost" onClick={() => setFilters(EMPTY_FILTERS)} disabled={!filtered}>
            <FilterX size={15} /> Clear filters
          </button>
        </div>
        <p className="muted small">
          Showing {formatNumber(events.length)} of {formatNumber(searchedEvents.length)} events. Dates use UTC.
        </p>
      </section>

      {events.length === 0 ? (
        <EmptyState
          title="No events match these filters"
          message="Try widening the date range or clearing a filter."
          actionLabel="Clear filters"
          onAction={() => setFilters(EMPTY_FILTERS)}
        />
      ) : (
        <>
          <div className="kpi-grid">
            <StatCard icon={Activity} label="Events in View" value={formatNumber(summary.total)} hint="After search and filters" tone="blue" />
            <StatCard icon={AlertTriangle} label="Model-flagged Anomalies" value={formatNumber(summary.anomalous)} hint="Predicted label = 1" tone="violet" />
            <StatCard icon={Percent} label="Anomaly Percentage" value={formatPercent(summary.anomalyRate)} hint="Anomalies / events in view" tone="cyan" />
            <StatCard icon={ShieldAlert} label="THREAT" value={formatNumber(summary.threat)} hint="Probability 0.67 or higher" tone="red" />
            <StatCard icon={ShieldAlert} label="Partial Threats" value={formatNumber(summary.partial)} hint="Probability 0.34 to below 0.67" tone="amber" />
          </div>

          <div className="grid-2">
            <ChartCard title="Threat Category Distribution" subtitle="Events per risk band" height={260}>
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={riskData} margin={{ top: 8, right: 8, bottom: 0, left: -12 }}>
                  <CartesianGrid stroke={CHART.grid} vertical={false} />
                  <XAxis dataKey="name" tick={AXIS_TICK} axisLine={false} tickLine={false} />
                  <YAxis allowDecimals={false} tick={AXIS_TICK} axisLine={false} tickLine={false} />
                  <Tooltip content={<ChartTooltip />} cursor={{ fill: 'rgba(139,124,246,0.08)' }} />
                  <Bar dataKey="value" name="Events" radius={[4, 4, 0, 0]} maxBarSize={72} isAnimationActive={false}>
                    {riskData.map((d) => (
                      <Cell key={d.name} fill={d.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </ChartCard>

            <ChartCard title="Anomalies by Activity Type" subtitle="Model-flagged anomalies only" height={260} empty={byActivity.length === 0}>
              <HBarChart data={byActivity} seriesName="Anomalies" color={CHART.violet} />
            </ChartCard>

            <ChartCard title="Anomalies by User" subtitle="Top users by model-flagged anomalies" height={260} empty={byUser.length === 0}>
              <HBarChart data={byUser} seriesName="Anomalies" color={CHART.blue} yAxisWidth={90} />
            </ChartCard>

            <ChartCard title="Anomalies by Decoder" subtitle="Log source that produced the event" height={260} empty={byDecoder.length === 0}>
              <HBarChart data={byDecoder} seriesName="Anomalies" color={CHART.cyan} />
            </ChartCard>

            <ChartCard title="Event-size Distribution" subtitle="Events per size bucket" height={260}>
              <StackedColumns data={sizes} xKey="bucket" />
            </ChartCard>

            <ChartCard title="Events by Hour of Day" subtitle="UTC hour of the event timestamp" height={260}>
              <StackedColumns data={hours} xKey="hour" minTickGap={8} />
            </ChartCard>
          </div>

          <section className="card">
            <header className="card__header">
              <h2 className="card__title">Highest-probability Events</h2>
              <p className="card__subtitle">Top 10 events in view by anomaly probability. Click a row for details.</p>
            </header>
            <EventTable events={topEvents} columns={TOP_COLUMNS} onRowClick={setOpenEvent} activeId={openEvent?.id} />
          </section>
        </>
      )}

      <EventDetails event={openEvent} onClose={() => setOpenEvent(null)} />
    </div>
  );
}
