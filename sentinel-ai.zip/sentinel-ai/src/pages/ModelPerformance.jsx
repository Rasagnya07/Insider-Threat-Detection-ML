import { useEffect, useState } from 'react';
import { AlertCircle, Hourglass } from 'lucide-react';
import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { API_BASE_URL, loadModelMetrics } from '../services/api';
import { formatNumber, formatPercent } from '../utils/formatters';
import { AXIS_TICK, CHART } from '../utils/theme';
import ChartCard from '../components/ChartCard';
import ChartTooltip from '../components/ChartTooltip';

const CONFIG = [
  ['Algorithm', 'Logistic Regression with Elastic Net regularization'],
  ['Penalty', 'elasticnet'],
  ['Solver', 'saga'],
  ['L1 ratio', '0.5'],
  ['C', '1.0'],
  ['Maximum iterations', '5000'],
  ['Train-test split', '80:20'],
  ['Target', 'Anomaly'],
];

const isNumber = (v) => typeof v === 'number' && Number.isFinite(v);

function Awaiting({ compact = false }) {
  return (
    <span className={`awaiting ${compact ? 'awaiting--compact' : ''}`}>
      <Hourglass size={compact ? 13 : 16} /> Awaiting model results
    </span>
  );
}

function MetricCard({ label, value, format }) {
  return (
    <div className="metric-card">
      <div className="metric-card__label">{label}</div>
      {isNumber(value) ? <div className="metric-card__value">{format(value)}</div> : <Awaiting compact />}
    </div>
  );
}

function ConfusionMatrix({ matrix }) {
  const ready = matrix && ['tn', 'fp', 'fn', 'tp'].every((k) => isNumber(matrix[k]));
  const cell = (value, label, tone) => (
    <div className={`cm__cell cm__cell--${tone}`}>
      <strong>{ready ? formatNumber(value) : '-'}</strong>
      <span>{label}</span>
    </div>
  );
  return (
    <div>
      <div className="cm">
        <div className="cm__corner" />
        <div className="cm__head">Predicted 0</div>
        <div className="cm__head">Predicted 1</div>
        <div className="cm__side">Actual 0</div>
        {cell(matrix?.tn, 'True negative', 'good')}
        {cell(matrix?.fp, 'False positive', 'bad')}
        <div className="cm__side">Actual 1</div>
        {cell(matrix?.fn, 'False negative', 'bad')}
        {cell(matrix?.tp, 'True positive', 'good')}
      </div>
      {!ready && <p className="muted small"><Awaiting compact /></p>}
    </div>
  );
}

function ClassificationReport({ rows }) {
  const ready = Array.isArray(rows) && rows.length > 0;
  const fallback = [
    { label: '0 (Non-anomalous)' },
    { label: '1 (Anomalous)' },
    { label: 'Macro average' },
    { label: 'Weighted average' },
  ];
  const show = (v, f) => (isNumber(v) ? f(v) : '-');
  return (
    <div>
      <div className="table-wrap">
        <table className="table table--compact">
          <thead>
            <tr>
              <th>Class</th>
              <th className="is-right">Precision</th>
              <th className="is-right">Recall</th>
              <th className="is-right">F1-score</th>
              <th className="is-right">Support</th>
            </tr>
          </thead>
          <tbody>
            {(ready ? rows : fallback).map((row) => (
              <tr key={row.label}>
                <td>{row.label}</td>
                <td className="is-right">{show(row.precision, (v) => v.toFixed(3))}</td>
                <td className="is-right">{show(row.recall, (v) => v.toFixed(3))}</td>
                <td className="is-right">{show(row.f1, (v) => v.toFixed(3))}</td>
                <td className="is-right">{show(row.support, formatNumber)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {!ready && <p className="muted small"><Awaiting compact /></p>}
    </div>
  );
}

export default function ModelPerformance() {
  const [state, setState] = useState({ loading: true, error: '', metrics: null, source: '', note: '' });

  useEffect(() => {
    let cancelled = false;
    loadModelMetrics()
      .then((data) => {
        if (!cancelled) setState({ loading: false, error: '', metrics: data.metrics, source: data.source, note: data.note || '' });
      })
      .catch((error) => {
        if (!cancelled) setState({ loading: false, error: error.message, metrics: null, source: '', note: '' });
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const { metrics, loading, error, source, note } = state;
  const m = metrics || {};

  const dist = m.classDistribution;
  const distReady = dist && dist.actual && dist.predicted;
  const distData = distReady
    ? [
        { name: 'Non-anomalous (0)', actual: dist.actual[0], predicted: dist.predicted[0] },
        { name: 'Anomalous (1)', actual: dist.actual[1], predicted: dist.predicted[1] },
      ]
    : [];

  const accuracyReady = isNumber(m.trainAccuracy) && isNumber(m.testAccuracy);
  const accuracyData = accuracyReady
    ? [
        { name: 'Training', value: +(m.trainAccuracy * 100).toFixed(2) },
        { name: 'Testing', value: +(m.testAccuracy * 100).toFixed(2) },
      ]
    : [];

  const anyMetric = ['accuracy', 'precision', 'recall', 'f1', 'rocAuc'].some((k) => isNumber(m[k]));

  if (loading) {
    return (
      <div className="page">
        <div className="loading-row">
          <span className="spinner" /> Loading model metrics...
        </div>
      </div>
    );
  }

  return (
    <div className="page">
      <p className="page-desc">
        Evaluation of the Elastic Net regularized logistic regression classifier on the held-out test split.
      </p>

      {error && (
        <div className="notice notice--error" role="alert">
          <AlertCircle size={16} />
          <span>Could not load model metrics: {error}</span>
        </div>
      )}

      <div className={`notice ${anyMetric ? 'notice--info' : 'notice--demo'}`}>
        <Hourglass size={16} />
        <span>
          {anyMetric ? (
            <>
              Metrics loaded from {source === 'backend' ? <strong>{API_BASE_URL}/api/metrics</strong> : <strong>src/data/modelMetrics.json</strong>}.
              {note && ` ${note}`}
            </>
          ) : (
            <>
              <strong>Awaiting model results.</strong> No evaluation metrics have been supplied yet, so none are shown. Add them
              to <code>src/data/modelMetrics.json</code> or serve them from <code>/api/metrics</code> (see README).
            </>
          )}
        </span>
      </div>

      <div className="kpi-grid">
        <MetricCard label="Test Accuracy" value={m.accuracy} format={(v) => formatPercent(v, 2)} />
        <MetricCard label="Precision" value={m.precision} format={(v) => formatPercent(v, 2)} />
        <MetricCard label="Recall" value={m.recall} format={(v) => formatPercent(v, 2)} />
        <MetricCard label="F1-Score" value={m.f1} format={(v) => formatPercent(v, 2)} />
        <MetricCard label="ROC-AUC" value={m.rocAuc} format={(v) => v.toFixed(3)} />
      </div>

      <div className="grid-2">
        <section className="card">
          <header className="card__header">
            <h2 className="card__title">Confusion Matrix</h2>
            <p className="card__subtitle">Test set, class 1 = anomalous</p>
          </header>
          <ConfusionMatrix matrix={m.confusionMatrix} />
        </section>

        <section className="card">
          <header className="card__header">
            <h2 className="card__title">Classification Report</h2>
            <p className="card__subtitle">Per-class precision, recall and F1</p>
          </header>
          <ClassificationReport rows={m.classificationReport} />
        </section>

        <ChartCard title="Actual vs Predicted Class Distribution" subtitle="Test set counts" height={260} empty={false}>
          {distReady ? (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={distData} margin={{ top: 8, right: 8, bottom: 0, left: -12 }}>
                <CartesianGrid stroke={CHART.grid} vertical={false} />
                <XAxis dataKey="name" tick={AXIS_TICK} axisLine={false} tickLine={false} />
                <YAxis allowDecimals={false} tick={AXIS_TICK} axisLine={false} tickLine={false} />
                <Tooltip content={<ChartTooltip />} cursor={{ fill: 'rgba(139,124,246,0.08)' }} />
                <Legend wrapperStyle={{ color: CHART.tick, fontSize: 12 }} />
                <Bar dataKey="actual" name="Actual" fill={CHART.blue} radius={[4, 4, 0, 0]} isAnimationActive={false} />
                <Bar dataKey="predicted" name="Predicted" fill={CHART.violet} radius={[4, 4, 0, 0]} isAnimationActive={false} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="chart-empty">
              <Awaiting />
            </div>
          )}
        </ChartCard>

        <ChartCard title="Training vs Testing Accuracy" subtitle="A large gap can indicate overfitting" height={260} empty={false}>
          {accuracyReady ? (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={accuracyData} margin={{ top: 8, right: 8, bottom: 0, left: -12 }}>
                <CartesianGrid stroke={CHART.grid} vertical={false} />
                <XAxis dataKey="name" tick={AXIS_TICK} axisLine={false} tickLine={false} />
                <YAxis domain={[0, 100]} unit="%" tick={AXIS_TICK} axisLine={false} tickLine={false} />
                <Tooltip content={<ChartTooltip />} cursor={{ fill: 'rgba(139,124,246,0.08)' }} />
                <Bar dataKey="value" name="Accuracy (%)" fill={CHART.cyan} radius={[4, 4, 0, 0]} maxBarSize={80} isAnimationActive={false} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="chart-empty">
              <Awaiting />
            </div>
          )}
        </ChartCard>
      </div>

      <div className="grid-2">
        <section className="card">
          <header className="card__header">
            <h2 className="card__title">Model Configuration</h2>
          </header>
          <dl className="config-list">
            {CONFIG.map(([key, value]) => (
              <div key={key}>
                <dt>{key}</dt>
                <dd>{['Penalty', 'Solver', 'Target'].includes(key) ? <code>{value}</code> : value}</dd>
              </div>
            ))}
          </dl>
        </section>

        <section className="card prose">
          <header className="card__header">
            <h2 className="card__title">How to read this model</h2>
          </header>
          <h3>L1 regularization (Lasso)</h3>
          <p>Penalizes the absolute size of coefficients and can shrink some to exactly zero, which removes weak features.</p>
          <h3>L2 regularization (Ridge)</h3>
          <p>Penalizes the squared size of coefficients. It shrinks them smoothly and copes well with correlated features.</p>
          <h3>Why Elastic Net combines both</h3>
          <p>
            With an L1 ratio of 0.5 the model gets feature selection from L1 and stability from L2, which suits log data
            with many encoded, correlated features.
          </p>
          <h3>Why precision and recall matter</h3>
          <p>
            Low recall means real insider activity goes unflagged. Low precision floods analysts with false alarms.
            Accuracy alone can hide both when anomalies are rare.
          </p>
        </section>
      </div>
    </div>
  );
}
