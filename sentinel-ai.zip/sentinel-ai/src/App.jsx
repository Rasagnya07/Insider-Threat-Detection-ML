import { useEffect, useState } from 'react';
import { Navigate, Route, Routes, useLocation } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import Topbar from './components/Topbar';
import Overview from './pages/Overview';
import ThreatAnalytics from './pages/ThreatAnalytics';
import ActivityLogs from './pages/ActivityLogs';
import PredictionLab from './pages/PredictionLab';
import ModelPerformance from './pages/ModelPerformance';
import AboutProject from './pages/AboutProject';

export default function App() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { pathname } = useLocation();

  // Start each page at the top.
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  return (
    <div className="app">
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div className="main">
        <Topbar onMenu={() => setSidebarOpen(true)} />
        <main className="content">
          <Routes>
            <Route path="/" element={<Overview />} />
            <Route path="/analytics" element={<ThreatAnalytics />} />
            <Route path="/logs" element={<ActivityLogs />} />
            <Route path="/prediction" element={<PredictionLab />} />
            <Route path="/performance" element={<ModelPerformance />} />
            <Route path="/about" element={<AboutProject />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </main>
      </div>
    </div>
  );
}
