// SIMULATED scoring used ONLY in demo mode.
// This is a hand-written heuristic that squashes a few event features through a logistic
// curve so the demo behaves plausibly. It is NOT the trained Elastic Net model and its
// outputs must always be labelled "simulated demo prediction".

import { ACTIVITY_PROFILES, ACTION_WEIGHT, LOG_LEVEL_WEIGHT } from '../data/constants';

const round3 = (n) => Math.round(n * 1000) / 1000;

export function simulateProbability(event, noise = 0) {
  const activityRisk = ACTIVITY_PROFILES[event.activity]?.risk ?? 0.3;
  const actionWeight = ACTION_WEIGHT[event.action] ?? 0.2;
  const hour = new Date(event.timestamp).getUTCHours();
  const offHours = !Number.isNaN(hour) && (hour < 6 || hour >= 21) ? 1 : 0;
  const sizeTerm = Math.max(0, Math.log10(Number(event.eventSize) + 1) - 4) * 0.55;
  const before = Number(event.sizeBefore) || 0;
  const after = Number(event.sizeAfter) || 0;
  const growth = before > 0 ? Math.min(2, Math.abs(after - before) / before) : 0;
  const levelWeight = LOG_LEVEL_WEIGHT[event.logLevel] ?? 0;
  const attachments = Math.min(Number(event.attachments) || 0, 5);

  const z =
    -2.5 +
    1.7 * activityRisk +
    0.9 * actionWeight +
    1.5 * offHours +
    sizeTerm +
    0.3 * attachments +
    0.4 * growth +
    levelWeight +
    noise;

  return round3(1 / (1 + Math.exp(-z)));
}
