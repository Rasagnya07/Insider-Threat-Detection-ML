// Colours shared by the Recharts components (CSS variables do not work in all SVG props).
export const CHART = {
  violet: '#8b7cf6',
  blue: '#4f7cf0',
  cyan: '#22d3ee',
  grid: '#1f2a44',
  tick: '#8b97b3',
  normal: '#4f7cf0',
  anomalous: '#f87171',
};

export const AXIS_TICK = { fill: CHART.tick, fontSize: 12 };
