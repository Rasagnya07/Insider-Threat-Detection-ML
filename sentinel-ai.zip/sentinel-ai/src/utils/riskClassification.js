// Risk classification: converts the binary classifier's anomaly probability
// into three display categories. The categories are NOT separately trained
// classes - they are probability bands.

export const THRESHOLDS = { partial: 0.34, threat: 0.67 };

// Probability cut-off used to turn the probability into the binary label (0/1).
export const LABEL_CUTOFF = 0.5;

export const RISK = {
  SAFE: 'SAFE',
  PARTIAL: 'PARTIAL THREAT',
  THREAT: 'THREAT',
};

export const RISK_ORDER = [RISK.SAFE, RISK.PARTIAL, RISK.THREAT];

export const RISK_META = {
  [RISK.SAFE]: {
    tone: 'safe',
    color: '#34d399',
    range: 'below 0.34',
    summary: 'Activity looks consistent with non-anomalous behaviour.',
  },
  [RISK.PARTIAL]: {
    tone: 'partial',
    color: '#fbbf24',
    range: '0.34 to below 0.67',
    summary: 'Activity shows some unusual characteristics and may merit a closer look.',
  },
  [RISK.THREAT]: {
    tone: 'threat',
    color: '#f87171',
    range: '0.67 or higher',
    summary: 'Activity was strongly flagged by the model and should be reviewed by an analyst.',
  },
};

export function classifyRisk(probability) {
  if (probability >= THRESHOLDS.threat) return RISK.THREAT;
  if (probability >= THRESHOLDS.partial) return RISK.PARTIAL;
  return RISK.SAFE;
}

export function predictedLabel(probability) {
  return probability >= LABEL_CUTOFF ? 1 : 0;
}

// Accepts values such as "partial_threat" or "Partial Threat" from a backend.
export function normalizeRiskName(value) {
  if (typeof value !== 'string') return null;
  const cleaned = value.trim().toUpperCase().replace(/[_-]+/g, ' ');
  return RISK_ORDER.includes(cleaned) ? cleaned : null;
}

export function formatProbability(probability) {
  return Number(probability).toFixed(3);
}

// Plain-language explanation shown in the event drawer and Prediction Lab.
export function explainResult(probability, risk, simulated) {
  const p = formatProbability(probability);
  const band = RISK_META[risk].range;
  const base =
    `The model-based risk estimate gives an anomaly probability of ${p}, which falls in the ${risk} band (${band}). ` +
    `${RISK_META[risk].summary} ` +
    'A model-flagged anomaly is potentially suspicious, not proof of malicious intent.';
  return simulated
    ? `${base} This value is a simulated demo prediction, not output from the trained model.`
    : base;
}

// Simple, human-readable observations taken from the event fields.
// These are NOT feature attributions from the model.
export function describeContext(event) {
  const notes = [];
  const hour = new Date(event.timestamp).getUTCHours();
  if (!Number.isNaN(hour) && (hour < 6 || hour >= 21)) notes.push('Occurred outside typical working hours (UTC).');
  if (event.eventSize >= 1048576) notes.push('Event size is above 1 MB.');
  if (event.attachments >= 3) notes.push('Three or more attachments were involved.');
  if (event.sizeBefore > 0 && Math.abs(event.sizeAfter - event.sizeBefore) / event.sizeBefore >= 0.5) {
    notes.push('Size changed by 50% or more during the operation.');
  }
  if (event.logLevel === 'warning' || event.logLevel === 'error') notes.push(`Logged at ${event.logLevel} level.`);
  return notes;
}
