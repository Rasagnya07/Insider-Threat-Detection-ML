// Pure helpers that turn an array of events into numbers for cards, charts and tables.
// Every page calls these with the SAME dataset so all views stay consistent.

import { RISK, RISK_ORDER } from './riskClassification';
import { formatDayLabel } from './formatters';

export function summarize(events) {
  const total = events.length;
  const anomalous = events.filter((e) => e.anomaly === 1).length;
  const safe = events.filter((e) => e.risk === RISK.SAFE).length;
  const partial = events.filter((e) => e.risk === RISK.PARTIAL).length;
  const threat = events.filter((e) => e.risk === RISK.THREAT).length;
  return {
    total,
    anomalous,
    normal: total - anomalous,
    safe,
    partial,
    threat,
    anomalyRate: total ? anomalous / total : 0,
    threatRate: total ? threat / total : 0,
  };
}

export function riskDistribution(events) {
  return RISK_ORDER.map((risk) => ({ name: risk, value: events.filter((e) => e.risk === risk).length }));
}

export function countBy(events, keyOf, { onlyAnomalous = false, limit } = {}) {
  const counts = new Map();
  for (const event of events) {
    if (onlyAnomalous && event.anomaly !== 1) continue;
    const key = keyOf(event);
    counts.set(key, (counts.get(key) || 0) + 1);
  }
  const rows = [...counts.entries()]
    .map(([name, value]) => ({ name, value }))
    .sort((a, b) => b.value - a.value || a.name.localeCompare(b.name));
  return limit ? rows.slice(0, limit) : rows;
}

// Events per calendar day (UTC), filling gaps so the line is continuous.
export function timelineByDay(events) {
  if (!events.length) return [];
  const byDay = new Map();
  for (const event of events) {
    const day = event.timestamp.slice(0, 10);
    const row = byDay.get(day) || { events: 0, anomalies: 0 };
    row.events += 1;
    if (event.anomaly === 1) row.anomalies += 1;
    byDay.set(day, row);
  }
  const days = [...byDay.keys()].sort();
  const result = [];
  const cursor = new Date(`${days[0]}T00:00:00Z`);
  const end = new Date(`${days[days.length - 1]}T00:00:00Z`);
  while (cursor <= end) {
    const key = cursor.toISOString().slice(0, 10);
    const row = byDay.get(key) || { events: 0, anomalies: 0 };
    result.push({ date: key, label: formatDayLabel(key), ...row });
    cursor.setUTCDate(cursor.getUTCDate() + 1);
  }
  return result;
}

export function eventsByHour(events) {
  const rows = Array.from({ length: 24 }, (_, h) => ({
    hour: String(h).padStart(2, '0'),
    normal: 0,
    anomalous: 0,
  }));
  for (const event of events) {
    const hour = new Date(event.timestamp).getUTCHours();
    if (Number.isNaN(hour)) continue;
    if (event.anomaly === 1) rows[hour].anomalous += 1;
    else rows[hour].normal += 1;
  }
  return rows;
}

const SIZE_BUCKETS = [
  { label: '< 1 KB', max: 1024 },
  { label: '1-10 KB', max: 10 * 1024 },
  { label: '10-100 KB', max: 100 * 1024 },
  { label: '0.1-1 MB', max: 1024 * 1024 },
  { label: '1-10 MB', max: 10 * 1024 * 1024 },
  { label: '> 10 MB', max: Infinity },
];

export function sizeDistribution(events) {
  const rows = SIZE_BUCKETS.map((b) => ({ bucket: b.label, normal: 0, anomalous: 0 }));
  for (const event of events) {
    const index = SIZE_BUCKETS.findIndex((b) => event.eventSize < b.max);
    if (event.anomaly === 1) rows[index].anomalous += 1;
    else rows[index].normal += 1;
  }
  return rows;
}

export function uniqueValues(events, key) {
  return [...new Set(events.map((e) => e[key]))].sort();
}

// Free-text search over the fields users are most likely to look for.
export function searchEvents(events, query) {
  const q = query.trim().toLowerCase();
  if (!q) return events;
  return events.filter((e) =>
    [e.id, e.user, e.agent, e.decoder, e.activity, e.action, e.risk].some((v) => String(v).toLowerCase().includes(q)),
  );
}

export const EMPTY_FILTERS = { from: '', to: '', user: '', activity: '', action: '', risk: '' };

export function hasActiveFilters(filters) {
  return Object.values(filters).some(Boolean);
}

export function applyFilters(events, filters) {
  return events.filter((e) => {
    const day = e.timestamp.slice(0, 10);
    if (filters.from && day < filters.from) return false;
    if (filters.to && day > filters.to) return false;
    if (filters.user && e.user !== filters.user) return false;
    if (filters.activity && e.activity !== filters.activity) return false;
    if (filters.action && e.action !== filters.action) return false;
    if (filters.risk && e.risk !== filters.risk) return false;
    return true;
  });
}

export function sortEvents(events, key, direction) {
  const factor = direction === 'asc' ? 1 : -1;
  const valueOf = (e) => (key === 'risk' ? RISK_ORDER.indexOf(e.risk) : e[key]);
  return [...events].sort((a, b) => {
    const va = valueOf(a);
    const vb = valueOf(b);
    let result;
    if (typeof va === 'number' && typeof vb === 'number') result = va - vb;
    else result = String(va).localeCompare(String(vb));
    return result * factor || a.timestamp.localeCompare(b.timestamp) * factor;
  });
}

export function eventsToCsv(events) {
  const columns = [
    'id', 'timestamp', 'user', 'agent', 'decoder', 'activity', 'action', 'logLevel',
    'eventSize', 'attachments', 'sizeBefore', 'sizeAfter', 'probability', 'risk',
  ];
  const escape = (value) => `"${String(value ?? '').replace(/"/g, '""')}"`;
  const lines = [columns.join(',')];
  for (const event of events) lines.push(columns.map((c) => escape(event[c])).join(','));
  return lines.join('\n');
}

export function downloadCsv(filename, csv) {
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}
