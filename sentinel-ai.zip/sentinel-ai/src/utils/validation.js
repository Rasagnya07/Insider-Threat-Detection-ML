import { ACTIVITIES, ACTIONS, LOG_LEVELS } from '../data/constants';

const TEXT_FIELDS = [
  ['user', 'User'],
  ['agent', 'Agent name'],
  ['decoder', 'Decoder name'],
];

const SIZE_FIELDS = [
  ['eventSize', 'Event size'],
  ['sizeBefore', 'Size before operation'],
  ['sizeAfter', 'Size after operation'],
];

// Returns { errors, values }. `values` is only meaningful when `errors` is empty.
export function validateEventForm(form) {
  const errors = {};
  const values = {};

  for (const [key, label] of TEXT_FIELDS) {
    const text = String(form[key] ?? '').trim();
    if (!text) errors[key] = `${label} is required.`;
    else if (text.length > 64) errors[key] = `${label} must be 64 characters or fewer.`;
    values[key] = text;
  }

  if (!ACTIVITIES.includes(form.activity)) errors.activity = 'Choose an activity type.';
  values.activity = form.activity;
  if (!ACTIONS.includes(form.action)) errors.action = 'Choose an action type.';
  values.action = form.action;
  if (!LOG_LEVELS.includes(form.logLevel)) errors.logLevel = 'Choose a log level.';
  values.logLevel = form.logLevel;

  for (const [key, label] of SIZE_FIELDS) {
    const raw = String(form[key] ?? '').trim();
    const number = Number(raw);
    if (raw === '') errors[key] = `${label} is required.`;
    else if (!Number.isFinite(number) || number < 0) errors[key] = `${label} must be a number of 0 or more.`;
    values[key] = number;
  }

  const attachmentsRaw = String(form.attachments ?? '').trim();
  const attachments = Number(attachmentsRaw);
  if (attachmentsRaw === '') errors.attachments = 'Attachment count is required.';
  else if (!Number.isInteger(attachments) || attachments < 0 || attachments > 100) {
    errors.attachments = 'Attachment count must be a whole number from 0 to 100.';
  }
  values.attachments = attachments;

  const date = new Date(`${form.timestamp}:00Z`);
  if (!form.timestamp || Number.isNaN(date.getTime())) errors.timestamp = 'Enter a valid date and time.';
  else values.timestamp = date.toISOString();

  return { errors, values };
}
