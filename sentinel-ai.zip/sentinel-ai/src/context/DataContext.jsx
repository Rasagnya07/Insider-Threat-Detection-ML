import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { DEMO_EVENTS } from '../data/demoData';
import { checkBackendHealth, fetchEvents, isBackendConfigured } from '../services/api';
import { searchEvents, summarize } from '../utils/analytics';

const DataContext = createContext(null);

// backendState: 'not-configured' | 'connected' | 'unreachable'
export function DataProvider({ children }) {
  const [events, setEvents] = useState(DEMO_EVENTS);
  const [source, setSource] = useState('demo');
  const [backendState, setBackendState] = useState(isBackendConfigured ? 'unreachable' : 'not-configured');
  const [status, setStatus] = useState(isBackendConfigured ? 'loading' : 'ready');
  const [error, setError] = useState('');
  const [lastRefreshed, setLastRefreshed] = useState(() => new Date());
  const [search, setSearch] = useState('');
  const requestId = useRef(0);

  const refresh = useCallback(async () => {
    const current = ++requestId.current;
    setStatus('loading');
    setError('');
    try {
      if (!isBackendConfigured) {
        // Demo mode: the seeded dataset is re-loaded; a short delay gives visible feedback.
        await new Promise((resolve) => setTimeout(resolve, 450));
        if (current !== requestId.current) return;
        setEvents(DEMO_EVENTS);
        setSource('demo');
        setBackendState('not-configured');
      } else if (await checkBackendHealth()) {
        const data = await fetchEvents();
        if (current !== requestId.current) return;
        setEvents(data.events);
        setSource('backend');
        setBackendState('connected');
      } else {
        if (current !== requestId.current) return;
        setEvents(DEMO_EVENTS);
        setSource('demo');
        setBackendState('unreachable');
      }
      setLastRefreshed(new Date());
      setStatus('ready');
    } catch (err) {
      if (current !== requestId.current) return;
      setBackendState('connected');
      setError(err.message || 'Could not load events from the backend.');
      setStatus('error');
    }
  }, []);

  // Only talks to the network when a backend URL has been configured.
  useEffect(() => {
    if (isBackendConfigured) refresh();
  }, [refresh]);

  const searchedEvents = useMemo(() => searchEvents(events, search), [events, search]);
  const summary = useMemo(() => summarize(events), [events]);

  const value = useMemo(
    () => ({
      events,
      searchedEvents,
      summary,
      source,
      backendState,
      status,
      error,
      lastRefreshed,
      search,
      setSearch,
      refresh,
    }),
    [events, searchedEvents, summary, source, backendState, status, error, lastRefreshed, search, refresh],
  );

  return <DataContext.Provider value={value}>{children}</DataContext.Provider>;
}

export function useData() {
  const context = useContext(DataContext);
  if (!context) throw new Error('useData must be used inside <DataProvider>');
  return context;
}
