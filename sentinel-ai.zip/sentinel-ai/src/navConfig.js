import { LayoutDashboard, ShieldAlert, ScrollText, FlaskConical, Gauge, Info } from 'lucide-react';

// Single source of truth for routes: used by the sidebar, the top bar and the router.
export const NAV_ITEMS = [
  { path: '/', label: 'Overview', title: 'Overview', icon: LayoutDashboard, searchable: true },
  { path: '/analytics', label: 'Threat Analytics', title: 'Threat Analytics', icon: ShieldAlert, searchable: true },
  { path: '/logs', label: 'Activity Logs', title: 'Activity Logs', icon: ScrollText, searchable: true },
  { path: '/prediction', label: 'Prediction Lab', title: 'Prediction Lab', icon: FlaskConical, searchable: false },
  { path: '/performance', label: 'Model Performance', title: 'Model Performance', icon: Gauge, searchable: false },
  { path: '/about', label: 'About the Project', title: 'About the Project', icon: Info, searchable: false },
];
