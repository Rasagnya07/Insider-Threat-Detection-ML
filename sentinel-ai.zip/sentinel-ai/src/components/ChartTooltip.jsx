// Dark tooltip shared by all Recharts charts.
export default function ChartTooltip({ active, payload, label }) {
  if (!active || !payload || payload.length === 0) return null;
  const heading = label !== undefined && label !== '' ? label : payload[0].name;
  return (
    <div className="chart-tooltip">
      <div className="chart-tooltip__label">{heading}</div>
      {payload.map((item) => (
        <div className="chart-tooltip__row" key={`${item.dataKey}-${item.name}`}>
          <span className="dot" style={{ background: item.color || item.payload?.fill || item.payload?.color }} />
          <span>{item.name}</span>
          <strong>{Number(item.value).toLocaleString('en-US')}</strong>
        </div>
      ))}
    </div>
  );
}
