import { AlertCircle, Database, Server, X } from 'lucide-react';
import { useData } from '../context/DataContext';
import { API_BASE_URL } from '../services/api';

// Top-of-page notice: data source (demo vs backend), load errors, and active search.
export default function DataBanner({ shown, total }) {
  const { source, backendState, status, error, search, setSearch, refresh } = useData();

  return (
    <div className="banners">
      {status === 'error' && (
        <div className="notice notice--error" role="alert">
          <AlertCircle size={16} />
          <span>{error}</span>
          <button type="button" className="btn btn--ghost btn--small" onClick={refresh}>
            Retry
          </button>
        </div>
      )}

      {source === 'demo' ? (
        <div className="notice notice--demo">
          <Database size={16} />
          <span>
            <strong>Synthetic demo data.</strong> These {total.toLocaleString('en-US')} records are generated for demonstration, not the SPEDIA dataset.
            Anomaly probabilities are simulated, not trained-model output.
            {backendState === 'unreachable' && ` The backend at ${API_BASE_URL} could not be reached.`}
          </span>
        </div>
      ) : (
        <div className="notice notice--ok">
          <Server size={16} />
          <span>
            <strong>Backend connected</strong> ({API_BASE_URL}). Showing {total.toLocaleString('en-US')} events from your data source.
          </span>
        </div>
      )}

      {search && (
        <div className="notice notice--info">
          <span>
            Search <strong>&ldquo;{search}&rdquo;</strong> is active: {shown.toLocaleString('en-US')} of {total.toLocaleString('en-US')} events match.
          </span>
          <button type="button" className="btn btn--ghost btn--small" onClick={() => setSearch('')}>
            <X size={13} /> Clear search
          </button>
        </div>
      )}
    </div>
  );
}
