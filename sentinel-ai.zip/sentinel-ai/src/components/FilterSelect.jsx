// Labelled <select> used by the filter bars. `options` is a list of strings.
export default function FilterSelect({ label, value, onChange, options, allLabel = 'All' }) {
  return (
    <label className="field field--inline">
      <span className="field__label">{label}</span>
      <select className="select" value={value} onChange={(e) => onChange(e.target.value)}>
        <option value="">{allLabel}</option>
        {options.map((option) => (
          <option key={option} value={option}>
            {option}
          </option>
        ))}
      </select>
    </label>
  );
}
