import { ArrowDown, ArrowUp, ArrowUpDown } from 'lucide-react';
import ThreatBadge from './ThreatBadge';
import { formatBytes, formatTimestamp } from '../utils/formatters';
import { formatProbability } from '../utils/riskClassification';

const COLUMNS = {
  id: { label: 'Event ID', render: (e) => <span className="mono">{e.id}</span> },
  timestamp: { label: 'Timestamp (UTC)', render: (e) => <span className="nowrap">{formatTimestamp(e.timestamp)}</span> },
  user: { label: 'User', render: (e) => e.user },
  agent: { label: 'Agent', render: (e) => <span className="mono">{e.agent}</span> },
  decoder: { label: 'Decoder', render: (e) => <span className="mono">{e.decoder}</span> },
  activity: { label: 'Activity', render: (e) => e.activity },
  action: { label: 'Action', render: (e) => <span className="tag">{e.action}</span> },
  eventSize: { label: 'Event size', align: 'right', render: (e) => <span className="nowrap">{formatBytes(e.eventSize)}</span> },
  attachments: { label: 'Attachments', align: 'right', render: (e) => e.attachments },
  probability: {
    label: 'Anomaly prob.',
    align: 'right',
    render: (e) => (
      <span className="prob">
        <span className="prob__bar">
          <span className={`prob__fill prob__fill--${e.risk === 'SAFE' ? 'safe' : e.risk === 'THREAT' ? 'threat' : 'partial'}`} style={{ width: `${e.probability * 100}%` }} />
        </span>
        {formatProbability(e.probability)}
      </span>
    ),
  },
  risk: { label: 'Risk category', render: (e) => <ThreatBadge risk={e.risk} /> },
};

export const ALL_COLUMNS = Object.keys(COLUMNS);

/**
 * Reusable event table.
 *  - columns:        which column keys to show (default all)
 *  - sort:           { key, direction } + onSort(key) enables sortable headers
 *  - selectedIds:    Set of ids + onToggle(id) + onToggleAll(ids, checked) enables checkboxes
 *  - onRowClick:     called with the event when a row is clicked / Enter is pressed
 *  - activeId:       highlights the row currently open in the detail drawer
 */
export default function EventTable({
  events,
  columns = ALL_COLUMNS,
  sort,
  onSort,
  selectedIds,
  onToggle,
  onToggleAll,
  onRowClick,
  activeId,
}) {
  const selectable = Boolean(selectedIds && onToggle);
  const allSelected = selectable && events.length > 0 && events.every((e) => selectedIds.has(e.id));

  return (
    <div className="table-wrap">
      <table className="table">
        <thead>
          <tr>
            {selectable && (
              <th className="table__check">
                <input
                  type="checkbox"
                  checked={allSelected}
                  onChange={(e) => onToggleAll(events.map((row) => row.id), e.target.checked)}
                  aria-label="Select all rows on this page"
                />
              </th>
            )}
            {columns.map((key) => {
              const column = COLUMNS[key];
              const sortable = Boolean(onSort);
              const active = sort && sort.key === key;
              const Icon = !active ? ArrowUpDown : sort.direction === 'asc' ? ArrowUp : ArrowDown;
              return (
                <th
                  key={key}
                  className={column.align === 'right' ? 'is-right' : ''}
                  aria-sort={active ? (sort.direction === 'asc' ? 'ascending' : 'descending') : undefined}
                >
                  {sortable ? (
                    <button type="button" className={`th-sort ${active ? 'th-sort--active' : ''}`} onClick={() => onSort(key)}>
                      {column.label}
                      <Icon size={13} />
                    </button>
                  ) : (
                    column.label
                  )}
                </th>
              );
            })}
          </tr>
        </thead>
        <tbody>
          {events.map((event) => {
            const selected = selectable && selectedIds.has(event.id);
            return (
              <tr
                key={event.id}
                className={`${onRowClick ? 'is-clickable' : ''} ${selected ? 'is-selected' : ''} ${activeId === event.id ? 'is-active' : ''}`}
                tabIndex={onRowClick ? 0 : undefined}
                onClick={onRowClick ? () => onRowClick(event) : undefined}
                onKeyDown={
                  onRowClick
                    ? (e) => {
                        if (e.key === 'Enter' || e.key === ' ') {
                          e.preventDefault();
                          onRowClick(event);
                        }
                      }
                    : undefined
                }
              >
                {selectable && (
                  <td className="table__check" onClick={(e) => e.stopPropagation()}>
                    <input
                      type="checkbox"
                      checked={selected}
                      onChange={() => onToggle(event.id)}
                      aria-label={`Select ${event.id}`}
                    />
                  </td>
                )}
                {columns.map((key) => (
                  <td key={key} className={COLUMNS[key].align === 'right' ? 'is-right' : ''}>
                    {COLUMNS[key].render(event)}
                  </td>
                ))}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
