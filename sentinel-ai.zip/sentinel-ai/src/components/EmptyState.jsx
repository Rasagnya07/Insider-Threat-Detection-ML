import { SearchX } from 'lucide-react';

export default function EmptyState({ title, message, actionLabel, onAction, icon: Icon = SearchX }) {
  return (
    <div className="empty">
      <span className="empty__icon">
        <Icon size={24} />
      </span>
      <h3>{title}</h3>
      {message && <p>{message}</p>}
      {actionLabel && onAction && (
        <button type="button" className="btn btn--ghost" onClick={onAction}>
          {actionLabel}
        </button>
      )}
    </div>
  );
}
