import { useEffect, useRef, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Bell, Database, Menu, RefreshCw, Search, Server, X } from 'lucide-react';
import { NAV_ITEMS } from '../navConfig';
import { useData } from '../context/DataContext';
import { RISK } from '../utils/riskClassification';
import { formatTimestamp } from '../utils/formatters';
import ThreatBadge from './ThreatBadge';

export default function Topbar({ onMenu }) {
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const { events, search, setSearch, refresh, status, lastRefreshed, backendState } = useData();
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const bellRef = useRef(null);

  const page = NAV_ITEMS.find((item) => item.path === pathname) || NAV_ITEMS[0];
  const alerts = events.filter((e) => e.risk === RISK.THREAT).slice(-5).reverse();
  const loading = status === 'loading';
  const connected = backendState === 'connected';

  // Close the notification menu on outside click or Escape.
  useEffect(() => {
    if (!notificationsOpen) return undefined;
    const onClick = (event) => {
      if (bellRef.current && !bellRef.current.contains(event.target)) setNotificationsOpen(false);
    };
    const onKey = (event) => {
      if (event.key === 'Escape') setNotificationsOpen(false);
    };
    document.addEventListener('mousedown', onClick);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onClick);
      document.removeEventListener('keydown', onKey);
    };
  }, [notificationsOpen]);

  const openAlert = (id) => {
    setNotificationsOpen(false);
    navigate(`/logs?event=${encodeURIComponent(id)}`);
  };

  return (
    <header className="topbar">
      <div className="topbar__left">
        <button type="button" className="icon-btn topbar__menu" onClick={onMenu} aria-label="Open navigation">
          <Menu size={20} />
        </button>
        <h1 className="topbar__title">{page.title}</h1>
      </div>

      <label className={`search ${page.searchable ? '' : 'search--disabled'}`}>
        <Search size={16} />
        <input
          type="search"
          value={search}
          disabled={!page.searchable}
          onChange={(e) => setSearch(e.target.value)}
          placeholder={page.searchable ? 'Search events, users, activities...' : 'Search is available on data pages'}
          aria-label="Search dashboard data"
        />
        {search && page.searchable && (
          <button type="button" className="icon-btn icon-btn--small" onClick={() => setSearch('')} aria-label="Clear search">
            <X size={14} />
          </button>
        )}
      </label>

      <div className="topbar__right">
        <span
          className={`pill ${connected ? 'pill--ok' : 'pill--demo'}`}
          title={`Last refreshed ${lastRefreshed.toLocaleTimeString()}`}
        >
          {connected ? <Server size={13} /> : <Database size={13} />}
          {connected ? 'Live backend data' : 'Synthetic demo data'}
        </span>

        <button
          type="button"
          className="icon-btn"
          onClick={refresh}
          disabled={loading}
          aria-label="Refresh data"
          title={connected ? 'Refresh from backend' : 'Reload demo data'}
        >
          <RefreshCw size={18} className={loading ? 'spin' : ''} />
        </button>

        <div className="menu-anchor" ref={bellRef}>
          <button
            type="button"
            className="icon-btn"
            onClick={() => setNotificationsOpen((v) => !v)}
            aria-label={`Notifications (${alerts.length})`}
            aria-expanded={notificationsOpen}
          >
            <Bell size={18} />
            {alerts.length > 0 && <span className="icon-btn__badge">{alerts.length}</span>}
          </button>
          {notificationsOpen && (
            <div className="menu" role="menu">
              <div className="menu__title">Latest THREAT-band events</div>
              {alerts.length === 0 && <div className="menu__empty">No THREAT-band events in the current data.</div>}
              {alerts.map((e) => (
                <button type="button" key={e.id} className="menu__item" role="menuitem" onClick={() => openAlert(e.id)}>
                  <span className="menu__item-top">
                    <span className="mono">{e.id}</span>
                    <ThreatBadge risk={e.risk} />
                  </span>
                  <span className="menu__item-sub">
                    {e.user} - {e.activity} - {formatTimestamp(e.timestamp)}
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="profile">
          <span className="avatar">SA</span>
          <span className="profile__name">Security Analyst</span>
        </div>
      </div>
    </header>
  );
}
