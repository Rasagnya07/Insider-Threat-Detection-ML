import { useEffect } from 'react';
import { FlaskConical, Info, X } from 'lucide-react';
import ProbabilityGauge from './ProbabilityGauge';
import ThreatBadge from './ThreatBadge';
import { formatBytes, formatTimestamp } from '../utils/formatters';
import { describeContext, explainResult } from '../utils/riskClassification';

// Slide-over drawer with every available field of one event.
export default function EventDetails({ event, onClose }) {
  useEffect(() => {
    if (!event) return undefined;
    const onKey = (e) => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [event, onClose]);

  if (!event) return null;

  const fields = [
    ['Timestamp (UTC)', formatTimestamp(event.timestamp)],
    ['User', event.user],
    ['Agent', event.agent],
    ['Decoder', event.decoder],
    ['Activity', event.activity],
    ['Action', event.action],
    ['Log level', event.logLevel],
    ['Event size', `${formatBytes(event.eventSize)} (${event.eventSize.toLocaleString('en-US')} B)`],
    ['Attachments', event.attachments],
    ['Size before', formatBytes(event.sizeBefore)],
    ['Size after', formatBytes(event.sizeAfter)],
    ['Predicted label', event.anomaly === 1 ? '1 - Anomalous' : '0 - Non-anomalous'],
  ];
  const context = describeContext(event);

  return (
    <>
      <div className="backdrop" onClick={onClose} aria-hidden="true" />
      <aside className="drawer" role="dialog" aria-modal="true" aria-label={`Details for ${event.id}`}>
        <header className="drawer__header">
          <div>
            <div className="drawer__eyebrow">Event details</div>
            <h2 className="mono">{event.id}</h2>
          </div>
          <button type="button" className="icon-btn" onClick={onClose} aria-label="Close details">
            <X size={18} />
          </button>
        </header>

        <div className="drawer__body">
          <div className="drawer__result">
            <ProbabilityGauge probability={event.probability} size={220} />
            <ThreatBadge risk={event.risk} />
            {event.simulated ? (
              <span className="pill pill--demo">
                <FlaskConical size={13} /> Simulated demo prediction
              </span>
            ) : (
              <span className="pill pill--ok">Model output from backend</span>
            )}
          </div>

          <dl className="detail-grid">
            {fields.map(([label, value]) => (
              <div key={label}>
                <dt>{label}</dt>
                <dd>{value}</dd>
              </div>
            ))}
          </dl>

          <section className="drawer__section">
            <h3>
              <Info size={15} /> What this result means
            </h3>
            <p>{explainResult(event.probability, event.risk, event.simulated)}</p>
          </section>

          {context.length > 0 && (
            <section className="drawer__section">
              <h3>Observed context</h3>
              <ul className="bullets">
                {context.map((note) => (
                  <li key={note}>{note}</li>
                ))}
              </ul>
              <p className="muted small">Simple observations from the event fields, not feature attributions from the model.</p>
            </section>
          )}
        </div>
      </aside>
    </>
  );
}
