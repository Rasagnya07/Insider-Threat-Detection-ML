import { NavLink } from 'react-router-dom';
import { Shield, X } from 'lucide-react';
import { NAV_ITEMS } from '../navConfig';
import { useData } from '../context/DataContext';
import { API_BASE_URL } from '../services/api';

const STATUS_TEXT = {
  'not-configured': { label: 'Demo data', detail: 'Synthetic records, simulated predictions', tone: 'demo' },
  unreachable: { label: 'Demo data', detail: 'Backend unreachable', tone: 'warn' },
  connected: { label: 'Backend connected', detail: API_BASE_URL, tone: 'ok' },
};

export default function Sidebar({ open, onClose }) {
  const { backendState } = useData();
  const status = STATUS_TEXT[backendState];

  return (
    <>
      {open && <div className="backdrop backdrop--sidebar" onClick={onClose} aria-hidden="true" />}
      <aside className={`sidebar ${open ? 'sidebar--open' : ''}`} aria-label="Primary">
        <div className="sidebar__brand">
          <span className="logo">
            <Shield size={20} />
          </span>
          <span className="sidebar__name">SentinelAI</span>
          <button type="button" className="icon-btn sidebar__close" onClick={onClose} aria-label="Close navigation">
            <X size={18} />
          </button>
        </div>

        <nav className="nav">
          {NAV_ITEMS.map(({ path, label, icon: Icon }) => (
            <NavLink
              key={path}
              to={path}
              end={path === '/'}
              onClick={onClose}
              className={({ isActive }) => `nav__link ${isActive ? 'nav__link--active' : ''}`}
            >
              <Icon size={18} />
              <span>{label}</span>
            </NavLink>
          ))}
        </nav>

        <div className="sidebar__status" role="status">
          <span className={`status-dot status-dot--${status.tone}`} />
          <div>
            <div className="sidebar__status-label">{status.label}</div>
            <div className="sidebar__status-detail">{status.detail}</div>
          </div>
        </div>
      </aside>
    </>
  );
}
