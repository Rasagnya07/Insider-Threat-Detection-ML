import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import ChartTooltip from './ChartTooltip';
import { AXIS_TICK, CHART } from '../utils/theme';

// Horizontal bar chart for ranked categories ({ name, value }[]).
export default function HBarChart({ data, color = CHART.violet, seriesName = 'Events', yAxisWidth = 120 }) {
  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart data={data} layout="vertical" margin={{ top: 4, right: 16, bottom: 0, left: 0 }}>
        <CartesianGrid stroke={CHART.grid} horizontal={false} />
        <XAxis type="number" allowDecimals={false} tick={AXIS_TICK} axisLine={false} tickLine={false} />
        <YAxis
          type="category"
          dataKey="name"
          width={yAxisWidth}
          tick={AXIS_TICK}
          axisLine={false}
          tickLine={false}
          interval={0}
        />
        <Tooltip content={<ChartTooltip />} cursor={{ fill: 'rgba(139,124,246,0.08)' }} />
        <Bar dataKey="value" name={seriesName} fill={color} radius={[0, 4, 4, 0]} barSize={16} isAnimationActive={false} />
      </BarChart>
    </ResponsiveContainer>
  );
}
