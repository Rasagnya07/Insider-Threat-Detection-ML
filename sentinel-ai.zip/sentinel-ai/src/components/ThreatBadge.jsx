import { RISK_META } from '../utils/riskClassification';

export default function ThreatBadge({ risk }) {
  const meta = RISK_META[risk];
  return <span className={`badge badge--${meta ? meta.tone : 'safe'}`}>{risk}</span>;
}
