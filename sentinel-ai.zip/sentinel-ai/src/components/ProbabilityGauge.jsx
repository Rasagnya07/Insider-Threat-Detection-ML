import { RISK_META, RISK, THRESHOLDS, classifyRisk, formatProbability } from '../utils/riskClassification';

const CX = 100;
const CY = 100;
const R = 78;

// Point on the half-circle for a probability p (0 = far left, 1 = far right).
const pointAt = (p, radius = R) => {
  const angle = Math.PI * (1 - p);
  return [CX + radius * Math.cos(angle), CY - radius * Math.sin(angle)];
};

const arc = (from, to) => {
  const [x1, y1] = pointAt(from);
  const [x2, y2] = pointAt(to);
  return `M ${x1.toFixed(2)} ${y1.toFixed(2)} A ${R} ${R} 0 0 1 ${x2.toFixed(2)} ${y2.toFixed(2)}`;
};

// Semicircle gauge: three colour bands (the risk thresholds) and a needle.
export default function ProbabilityGauge({ probability, size = 240 }) {
  const p = Math.min(1, Math.max(0, probability));
  const risk = classifyRisk(p);
  const [nx, ny] = pointAt(p, R - 14);

  return (
    <div className="gauge" style={{ width: size }}>
      <svg viewBox="0 0 200 118" role="img" aria-label={`Anomaly probability ${formatProbability(p)}, ${risk}`}>
        <path d={arc(0, THRESHOLDS.partial)} stroke={RISK_META[RISK.SAFE].color} className="gauge__band" />
        <path d={arc(THRESHOLDS.partial, THRESHOLDS.threat)} stroke={RISK_META[RISK.PARTIAL].color} className="gauge__band" />
        <path d={arc(THRESHOLDS.threat, 1)} stroke={RISK_META[RISK.THREAT].color} className="gauge__band" />
        <line x1={CX} y1={CY} x2={nx} y2={ny} className="gauge__needle" />
        <circle cx={CX} cy={CY} r="6" className="gauge__hub" />
        <text x="14" y="116" className="gauge__tick">0</text>
        <text x="186" y="116" className="gauge__tick" textAnchor="end">1</text>
      </svg>
      <div className="gauge__value" style={{ color: RISK_META[risk].color }}>
        {formatProbability(p)}
      </div>
      <div className="gauge__caption">anomaly probability</div>
    </div>
  );
}
