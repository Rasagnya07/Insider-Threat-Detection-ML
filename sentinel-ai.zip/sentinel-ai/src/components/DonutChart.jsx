import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from 'recharts';
import ChartTooltip from './ChartTooltip';
import { formatPercent } from '../utils/formatters';

// Donut with a centre label and a custom legend (counts + share).
export default function DonutChart({ data, centerValue, centerLabel }) {
  const total = data.reduce((sum, d) => sum + d.value, 0);
  return (
    <div className="donut">
      <div className="donut__chart">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              dataKey="value"
              nameKey="name"
              innerRadius="62%"
              outerRadius="90%"
              paddingAngle={data.filter((d) => d.value > 0).length > 1 ? 2 : 0}
              stroke="none"
              isAnimationActive={false}
            >
              {data.map((d) => (
                <Cell key={d.name} fill={d.color} />
              ))}
            </Pie>
            <Tooltip content={<ChartTooltip />} />
          </PieChart>
        </ResponsiveContainer>
        <div className="donut__center">
          <strong>{centerValue}</strong>
          <span>{centerLabel}</span>
        </div>
      </div>
      <ul className="legend">
        {data.map((d) => (
          <li key={d.name}>
            <span className="dot" style={{ background: d.color }} />
            <span className="legend__name">{d.name}</span>
            <span className="legend__value">
              {d.value.toLocaleString('en-US')} <em>{total ? formatPercent(d.value / total, 0) : '0%'}</em>
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}
