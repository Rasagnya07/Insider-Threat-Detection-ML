import { BarChart3 } from 'lucide-react';

// Card wrapper for charts. Gives the chart a fixed height (needed by ResponsiveContainer)
// and shows a friendly message when there is nothing to plot.
export default function ChartCard({ title, subtitle, height = 260, empty = false, className = '', children }) {
  return (
    <section className={`card ${className}`}>
      <header className="card__header">
        <h2 className="card__title">{title}</h2>
        {subtitle && <p className="card__subtitle">{subtitle}</p>}
      </header>
      <div className="chart-box" style={{ height }}>
        {empty ? (
          <div className="chart-empty">
            <BarChart3 size={22} />
            <span>No data for the current filters</span>
          </div>
        ) : (
          children
        )}
      </div>
    </section>
  );
}
