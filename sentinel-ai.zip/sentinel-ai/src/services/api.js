// All backend communication lives here. Pages never call fetch() directly.
//
// Backend URL comes from VITE_API_BASE_URL (see .env.example). If it is not set the
// app stays in demo mode and makes NO network requests.
//
// Expected endpoints (documented in README):
//   GET  /api/health   -> { "status": "ok" }
//   POST /api/predict  -> { "probability": 0.82, "label": 1, "riskCategory": "THREAT" }
//   GET  /api/events   -> { "events": [ ...event records ] }        (optional)
//   GET  /api/metrics  -> model evaluation metrics JSON             (optional)

import { DEMO_EVENTS } from '../data/demoData';
import localMetrics from '../data/modelMetrics.json';
import { simulateProbability } from '../utils/demoModel';
import { classifyRisk, normalizeRiskName, predictedLabel } from '../utils/riskClassification';

const BASE_URL = (import.meta.env.VITE_API_BASE_URL || '').trim().replace(/\/+$/, '');

export const API_BASE_URL = BASE_URL;
export const isBackendConfigured = BASE_URL.length > 0;

const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function request(path, options = {}, timeoutMs = 6000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(`${BASE_URL}${path}`, {
      ...options,
      headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
      signal: controller.signal,
    });
    if (!response.ok) throw new Error(`Backend responded with HTTP ${response.status}`);
    return await response.json();
  } finally {
    clearTimeout(timer);
  }
}

export async function checkBackendHealth() {
  if (!isBackendConfigured) return false;
  try {
    await request('/api/health', {}, 3000);
    return true;
  } catch {
    return false;
  }
}

// Accept either camelCase or snake_case field names from the backend.
function normalizeEvent(raw, index) {
  const probability = Number(raw.probability ?? raw.anomaly_probability);
  if (!Number.isFinite(probability)) return null;
  return {
    id: String(raw.id ?? raw.event_id ?? `EVT-${String(index + 1).padStart(5, '0')}`),
    timestamp: String(raw.timestamp ?? ''),
    user: String(raw.user ?? ''),
    agent: String(raw.agent ?? raw.agent_name ?? ''),
    decoder: String(raw.decoder ?? raw.decoder_name ?? ''),
    activity: String(raw.activity ?? raw.activity_type ?? ''),
    action: String(raw.action ?? raw.action_type ?? ''),
    logLevel: String(raw.logLevel ?? raw.log_level ?? 'info'),
    eventSize: Number(raw.eventSize ?? raw.event_size ?? 0),
    attachments: Number(raw.attachments ?? 0),
    sizeBefore: Number(raw.sizeBefore ?? raw.size_before ?? 0),
    sizeAfter: Number(raw.sizeAfter ?? raw.size_after ?? 0),
    probability,
    anomaly: Number(raw.label ?? raw.anomaly ?? raw.predicted_label ?? predictedLabel(probability)),
    risk: normalizeRiskName(raw.riskCategory ?? raw.risk_category ?? raw.risk) ?? classifyRisk(probability),
    simulated: false,
  };
}

/** Events for the dashboard. Returns demo records when no backend is available. */
export async function fetchEvents() {
  if (!isBackendConfigured) return { events: DEMO_EVENTS, source: 'demo' };
  const data = await request('/api/events');
  const list = Array.isArray(data) ? data : data.events;
  if (!Array.isArray(list)) throw new Error('Unexpected /api/events response: expected an "events" array.');
  return { events: list.map(normalizeEvent).filter(Boolean), source: 'backend' };
}

function demoPrediction(event, fallbackReason) {
  const probability = simulateProbability(event);
  return {
    probability,
    label: predictedLabel(probability),
    riskCategory: classifyRisk(probability),
    source: 'demo',
    simulated: true,
    fallbackReason,
  };
}

/**
 * Predict the anomaly probability of one event.
 * Backend reachable  -> real model output (source: "backend").
 * Otherwise          -> simulated demo result (source: "demo", simulated: true).
 */
export async function predictEvent(event) {
  if (!isBackendConfigured) {
    await wait(700);
    return demoPrediction(event, 'No backend is configured (VITE_API_BASE_URL is empty).');
  }
  try {
    const data = await request('/api/predict', { method: 'POST', body: JSON.stringify(event) }, 10000);
    const probability = Number(data.probability ?? data.anomaly_probability);
    if (!Number.isFinite(probability) || probability < 0 || probability > 1) {
      throw new Error('The backend response did not contain a probability between 0 and 1.');
    }
    const label = Number(data.label ?? data.predicted_label ?? data.prediction ?? predictedLabel(probability));
    return {
      probability,
      label,
      riskCategory: normalizeRiskName(data.riskCategory ?? data.risk_category) ?? classifyRisk(probability),
      source: 'backend',
      simulated: false,
    };
  } catch (error) {
    return demoPrediction(event, `Backend request failed (${error.message}).`);
  }
}

/** Model evaluation metrics: backend first, then the local JSON file. */
export async function loadModelMetrics() {
  if (isBackendConfigured) {
    try {
      const metrics = await request('/api/metrics');
      return { metrics, source: 'backend' };
    } catch {
      return { metrics: localMetrics, source: 'local', note: 'Backend metrics unavailable; showing local file.' };
    }
  }
  return { metrics: localMetrics, source: 'local' };
}
