// Synthetic demo dataset. NOT the SPEDIA Annotated Dataset.
// Generated with a fixed seed so the records are identical on every load/refresh.
// Probabilities are simulated (see utils/demoModel.js), not trained-model output.

import { USER_PROFILES, ACTIVITY_PROFILES } from './constants';
import { simulateProbability } from '../utils/demoModel';
import { classifyRisk, predictedLabel } from '../utils/riskClassification';

const SEED = 20261014;
const EVENT_COUNT = 144;
const DAYS = 14;
const FIRST_DAY = Date.UTC(2026, 9, 1); // 1 Oct 2026

// mulberry32: tiny deterministic PRNG
function createRandom(seed) {
  let a = seed;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function weightedPick(random, items, weightOf) {
  const total = items.reduce((sum, item) => sum + weightOf(item), 0);
  let roll = random() * total;
  for (const item of items) {
    roll -= weightOf(item);
    if (roll <= 0) return item;
  }
  return items[items.length - 1];
}

const pick = (random, list) => list[Math.floor(random() * list.length)];

function generateEvents() {
  const random = createRandom(SEED);
  const activityNames = Object.keys(ACTIVITY_PROFILES);
  const raw = [];

  for (let i = 0; i < EVENT_COUNT; i += 1) {
    const profile = weightedPick(random, USER_PROFILES, (p) => 1 + p.riskiness * 0.6);
    const activity = weightedPick(random, activityNames, (name) => {
      const a = ACTIVITY_PROFILES[name];
      return a.risk >= 0.6 ? a.weight * (0.5 + 2 * profile.riskiness) : a.weight;
    });
    const spec = ACTIVITY_PROFILES[activity];
    const decoder = pick(random, spec.decoders);
    const action = pick(random, spec.actions);

    const offHours = random() < 0.06 + 0.35 * profile.riskiness;
    const hour = offHours ? pick(random, [0, 1, 2, 3, 4, 5, 22, 23]) : 8 + Math.floor(random() * 11);
    const day = Math.floor(random() * DAYS);
    const timestamp = new Date(
      FIRST_DAY + day * 86400000 + hour * 3600000 + Math.floor(random() * 60) * 60000 + Math.floor(random() * 60) * 1000,
    ).toISOString();

    const [lo, hi] = spec.sizeLog;
    let eventSize = Math.round(10 ** (lo + random() * (hi - lo)));
    if (random() < 0.05 + 0.2 * profile.riskiness) eventSize *= 15;

    let attachments = 0;
    if (activity === 'Email Send') attachments = Math.floor(random() * (2 + profile.riskiness * 4));
    if (activity === 'Web Upload') attachments = 1 + Math.floor(random() * 3);

    const sizeBefore = eventSize;
    let sizeAfter = eventSize;
    if (action === 'delete') sizeAfter = 0;
    else if (action === 'modify' || action === 'write') sizeAfter = Math.round(eventSize * (0.5 + random() * 1.3));

    const logLevel = random() < 0.78 ? 'info' : random() < 0.6 ? 'notice' : random() < 0.7 ? 'warning' : 'error';
    const noise = (random() - 0.5) * 1.3;

    raw.push({
      timestamp,
      user: profile.user,
      agent: profile.agent,
      decoder,
      activity,
      action,
      logLevel,
      eventSize,
      attachments,
      sizeBefore,
      sizeAfter,
      noise,
    });
  }

  return raw
    .sort((a, b) => a.timestamp.localeCompare(b.timestamp))
    .map(({ noise, ...event }, index) => {
      const probability = simulateProbability(event, noise);
      return {
        id: `EVT-${String(index + 1).padStart(5, '0')}`,
        ...event,
        probability,
        anomaly: predictedLabel(probability),
        risk: classifyRisk(probability),
        simulated: true,
      };
    });
}

export const DEMO_EVENTS = generateEvents();

export const DEMO_META = {
  name: 'Synthetic demo data',
  description:
    'Randomly generated with a fixed seed for demonstration. This is not the SPEDIA Annotated Dataset, ' +
    'and the anomaly probabilities are simulated rather than produced by the trained model.',
};
