// Domain vocabulary used by the demo data generator and the Prediction Lab form.
// When you import real SPEDIA data you can keep these lists or derive them from the data.

export const USER_PROFILES = [
  { user: 'a.sharma', agent: 'WKS-HYD-014', riskiness: 0.1 },
  { user: 'm.chen', agent: 'WKS-SIN-022', riskiness: 0.15 },
  { user: 'j.okafor', agent: 'WKS-LOS-007', riskiness: 0.2 },
  { user: 'l.fernandez', agent: 'WKS-MAD-031', riskiness: 0.1 },
  { user: 'r.patel', agent: 'WKS-HYD-019', riskiness: 0.25 },
  { user: 's.novak', agent: 'WKS-PRG-003', riskiness: 0.8 },
  { user: 't.nakamura', agent: 'WKS-TYO-011', riskiness: 0.15 },
  { user: 'd.alvarez', agent: 'LAP-MEX-045', riskiness: 0.65 },
  { user: 'k.haddad', agent: 'WKS-DXB-016', riskiness: 0.3 },
  { user: 'p.iyer', agent: 'WKS-BLR-028', riskiness: 0.2 },
];

// Per-activity behaviour: typical decoders/actions, relative frequency, inherent risk weight,
// and the log10(bytes) range used when generating event sizes.
export const ACTIVITY_PROFILES = {
  'File Access': {
    decoders: ['fileserver_audit', 'sysmon'],
    actions: ['read', 'modify', 'delete'],
    weight: 30,
    risk: 0.2,
    sizeLog: [3, 6.2],
  },
  Login: {
    decoders: ['windows_eventlog', 'auditd'],
    actions: ['login', 'logout', 'failed_login'],
    weight: 22,
    risk: 0.1,
    sizeLog: [2.3, 3.3],
  },
  'Email Send': {
    decoders: ['office365_audit'],
    actions: ['send'],
    weight: 14,
    risk: 0.5,
    sizeLog: [3.5, 6.5],
  },
  'File Copy': {
    decoders: ['fileserver_audit', 'usb_monitor'],
    actions: ['copy'],
    weight: 8,
    risk: 0.6,
    sizeLog: [4, 7],
  },
  'Print Job': {
    decoders: ['print_server'],
    actions: ['print'],
    weight: 7,
    risk: 0.3,
    sizeLog: [4, 6],
  },
  'USB Device': {
    decoders: ['usb_monitor'],
    actions: ['connect', 'write'],
    weight: 5,
    risk: 0.8,
    sizeLog: [3, 7.5],
  },
  'Web Upload': {
    decoders: ['proxy_gateway'],
    actions: ['upload'],
    weight: 5,
    risk: 0.9,
    sizeLog: [4, 7.5],
  },
  'Privilege Change': {
    decoders: ['windows_eventlog', 'auditd'],
    actions: ['modify', 'grant'],
    weight: 3,
    risk: 1,
    sizeLog: [2.3, 3.3],
  },
};

export const ACTION_WEIGHT = {
  read: 0,
  modify: 0.3,
  delete: 0.6,
  copy: 0.7,
  send: 0.4,
  login: 0,
  logout: -0.2,
  failed_login: 0.9,
  connect: 0.3,
  write: 0.5,
  upload: 0.8,
  print: 0.2,
  grant: 1,
};

export const LOG_LEVEL_WEIGHT = { info: 0, notice: 0.1, warning: 0.5, error: 0.8 };

export const USERS = USER_PROFILES.map((p) => p.user);
export const AGENTS = USER_PROFILES.map((p) => p.agent);
export const ACTIVITIES = Object.keys(ACTIVITY_PROFILES);
export const DECODERS = [...new Set(Object.values(ACTIVITY_PROFILES).flatMap((a) => a.decoders))].sort();
export const ACTIONS = Object.keys(ACTION_WEIGHT).sort();
export const LOG_LEVELS = Object.keys(LOG_LEVEL_WEIGHT);
